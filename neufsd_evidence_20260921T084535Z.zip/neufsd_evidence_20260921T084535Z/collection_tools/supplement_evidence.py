from pathlib import Path
import os, json, csv, hashlib, stat, subprocess, re
DEST=Path(__file__).parent; OUT=Path((DEST/'CURRENT_EXPORT.txt').read_text().strip())
A=Path('/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC');B=Path('/zhaoguangxiang-data-zzzc/shiqilong/MRAC')
rows=[]; links=[]; assets=[]
def put(p,rid):
    root=A if rid=='A' else B
    try:
        st=p.stat()
        if not stat.S_ISREG(st.st_mode) or st.st_size>5_000_000:return
        data=p.read_bytes();rel=p.relative_to(root);target=Path('source')/rid/rel
        (OUT/target).parent.mkdir(parents=True,exist_ok=True);(OUT/target).write_bytes(data)
        rows.append(dict(root_id=rid,original_path=str(p),relative_path=str(rel),realpath=str(p.resolve()),device=st.st_dev,inode=st.st_ino,source_size_bytes=st.st_size,mtime_ns_clue_only=st.st_mtime_ns,package_path=str(target),package_size_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),copy_mode='full',source_unchanged_during_copy=p.stat().st_mtime_ns==st.st_mtime_ns,paper_identity='candidate; see provenance report'))
    except OSError as e: assets.append({'path':str(p),'status':repr(e),'size_bytes':'','device':'','inode':'','sha256':'not computed','reason':'explicitly referenced small artifact'})
def asset(p,reason,record_size=None):
    d={'path':str(p),'status':'','size_bytes':'','device':'','inode':'','sha256':'not computed; large inputs/checkpoints were not read','reason':reason}
    try:
        st=p.stat();d.update(status='exists',size_bytes=st.st_size,device=st.st_dev,inode=st.st_ino)
        if record_size:d['reason']+=f'; size / {record_size} = {st.st_size//record_size} records, remainder {st.st_size%record_size}; {st.st_size//record_size//1000000} full 1M windows (size-derived, not parser verification)'
    except OSError as e:d['status']=repr(e)
    assets.append(d)
def link(p):
    if not p.is_symlink():return
    target=os.readlink(p); real=p.resolve();scope='A' if real.is_relative_to(A.resolve()) else 'B' if real.is_relative_to(B.resolve()) else 'external_reference'
    links.append({'referring_file':str(p),'field_or_line':'symlink target','literal_path':target,'recorded_cwd':'not applicable; relative symlink uses parent','resolved_candidate':str(real),'root_id':scope,'realpath':str(real),'exists':real.exists(),'resolution_status':'symlink_exact','evidence':'os.readlink; no recursive follow'})

for root,rid in [(A,'A'),(B,'B')]:
    for trace in ['caida_2016','caida_2018','caida_2018_new','imc','mawi']:
        for name in ['train_test_name_key.json','metadata.json','manifest.json','prepare_summary.json']:
            p=root/'zipf_fsd_release/data_full'/trace/name
            if p.is_file():put(p,rid)
    for rel in ['zipf_fsd_release/data_full/caida_2016/caida/formatted00.dat','zipf_fsd_release/data_full/caida_2018/caida/130000.dat','imc_univ2_5tuple_keys_13B.dat','mawi_20230718_5tuple_keys_13B.dat']:
        p=root/rel;size=16 if 'formatted00' in rel else 21 if '130000' in rel else 13;asset(p,'trace referenced by HANDOFF and plot_real_fsd_examples_paper.py',size);link(p)
    p=root/'zipf_fsd_release/data_full'
    if p.exists():
        for trace in ['caida_2016','caida_2018','imc','mawi']:
            for name in ['caida','caida_1min_split','tr_ts','tr_ts_finetuned_continue']:
                q=p/trace/name;link(q)

base=A/'zipf_fsd_release/mainonly_runs_20260623'
for trace in ['caida2016','caida2018','imc','mawi']:
    p=base/'sliding_fullstack_online'/('sample_cache_'+trace)
    for rel in ['sample_cache_summary.json','sample_cache_timing.csv','input_store/index.json']:
        if (p/rel).is_file():put(p/rel,'A')
for trace in ['caida_2016','caida_2018','imc','mawi']:
    p=base/'pretrain_fourdatasets/roots'/('64_64_'+trace+'_first8')
    for name in ['1_10_chazhi','1_10_real','10_1e4_chazhi','10_1e4_real']:
        link(p/name)
    asset(p/'input_store/counters.u4','four-dataset prior counter store, indexed separately')
for head,score in [('1_10','25.745088'),('10_1e4','26.394901')]:
    asset(base/f'pretrain_fourdatasets/pretrained/64_64/ViT_{head}_results_1e-2/best_model_{score}.pth','checkpoint name matches online args and pretraining log tail; no deserialization or full hash')
for name in ['window_metrics.csv','summary.csv','args.json']:
    put(base/'imc_current_oracle_20260630/p50_s2000_e20_full'/name,'A')
for p in [A/'overleaf',A/'overleaf/NeuFSD-sigmetrics.tex',A/'overleaf/appendix-KDD.tex']:
    try:
        with p.open('rb') as f:f.read(1)
    except OSError as e:assets.append({'path':str(p),'status':repr(e),'size_bytes':'','device':'','inode':'','sha256':'not computed','reason':'submission figure/table identity cannot be read through this path'})
# Capture exact indexes for parser/conversion provenance without reading trace archives.
for p in [A/'CAIDA2016.zip',A/'130x.zip',A/'131x.zip',A/'132x.zip',A/'MRAC_fsd_sketch_reproduction_20260722.tar.gz',A/'zipf_fsd_release_handoff_20260615.tar.gz']:
    asset(p,'existing archive; not extracted or used to choose final version')

(OUT/'records/supplement_manifest.json').write_text(json.dumps(rows,indent=2))
for name,data,fields in [('artifact_identity.csv',assets,['path','status','size_bytes','device','inode','sha256','reason']),('links_resolution.csv',links,['referring_file','field_or_line','literal_path','recorded_cwd','resolved_candidate','root_id','realpath','exists','resolution_status','evidence'])]:
    with (OUT/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
print(json.dumps({'supplement_files':len(rows),'asset_records':len(assets),'links':len(links)}))
