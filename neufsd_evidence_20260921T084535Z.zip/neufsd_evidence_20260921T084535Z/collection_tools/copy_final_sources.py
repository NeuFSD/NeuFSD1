from pathlib import Path
import json,csv,hashlib,signal,time,os
D=Path(__file__).parent;O=Path((D/'CURRENT_EXPORT.txt').read_text().strip());A=Path('/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC')
rows=json.loads((O/'records/supplement_manifest.json').read_text());errors=[];paths=set()
for name in ['A_target_index.txt','A_run_index.txt','A_final_index.txt']:
 for s in (O/'records'/name).read_text().splitlines():
  p=Path(s)
  if any(x.startswith('.') for x in p.relative_to(A).parts):continue
  keep=False
  if '/final_e5/' in s and p.suffix in {'.csv','.json'} and '/train_cache/' not in s:keep=True
  if '/pretrain_fourdatasets/' in s and p.suffix in {'.log','.json'}:keep=True
  if '/configs/' in s and '/NeuFSD1/' not in s and p.suffix in {'.py','.c','.cpp','.h'}:keep=True
  if '/comprehensive_compare_20260630/plots' in s:keep=True
  if '/perf_eval_20260630/' in s and any(x in s for x in ['/plots/','/sweeps/','/ablations/']) and p.suffix in {'.csv','.pdf'}:keep=True
  if any(x in s for x in ['/residual_calibration_20260629/','/sft_strategy_comparison_20260629/','/final_memory_sweep_10x/']) and p.suffix in {'.csv','.json','.md','.pdf'}:keep=True
  if '/ablation_continuous_pretrain_20260628/' in s and p.suffix in {'.csv','.json'}:keep=True
  if '/zipf_exact/' in s and p.name in {'manifest.json','index.json'}:keep=True
  if '/counter_store/' in s and p.name=='index.json':keep=True
  if '/zipf_fsd_release/compare/caida_org/' in s and p.name in {'main.cpp','traditional_sample.cpp','davinci_runner.cpp','common_func.h'}:keep=True
  if keep:paths.add(p)
for s in ['zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/p50_s2000_e20_full/window_metrics.csv','zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/p50_s2000_e20_full/summary.csv']:paths.add(A/s)
def fail(*args):raise TimeoutError('3s shared filesystem read timeout')
signal.signal(signal.SIGALRM,fail)
def tail(p):
 with p.open('rb') as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-131072));b=f.read()
 return b'\n'.join(b.splitlines()[-300:])+b'\n'
for p in sorted(paths,key=lambda p:(0 if '/final_e5/' in str(p) and p.suffix=='.csv' else 1 if '/pretrain_fourdatasets/' in str(p) else 2 if p.suffix!='.pdf' else 3,str(p))):
 try:
  signal.setitimer(signal.ITIMER_REAL,3)
  rel=p.relative_to(A);islog=p.suffix=='.log';target=Path('records/A' if islog else 'source/A')/rel
  if islog:target=Path(str(target)+'.tail300.txt')
  dst=O/target;st=p.stat()
  if st.st_size>5_000_000 and not islog:errors.append({'path':str(p),'error':'file >5MB'});continue
  data=dst.read_bytes() if dst.exists() else tail(p) if islog else p.read_bytes()
  if not dst.exists():dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
  rows.append(dict(root_id='A',original_path=str(p),relative_path=str(rel),realpath=str(p.resolve()),device=st.st_dev,inode=st.st_ino,source_size_bytes=st.st_size,mtime_ns_clue_only=st.st_mtime_ns,package_path=str(target),package_size_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),copy_mode='tail_300_lines_max_128KiB' if islog else 'full',source_unchanged_during_copy=st.st_mtime_ns==p.stat().st_mtime_ns,paper_identity='candidate; see provenance report'))
 except OSError as e:errors.append({'path':str(p),'error':repr(e)})
 finally:signal.setitimer(signal.ITIMER_REAL,0)
(O/'records/supplement_manifest.json').write_text(json.dumps(list({r['package_path']:r for r in rows}.values()),indent=2));(O/'records/final_copy_errors.json').write_text(json.dumps(errors,indent=2));print(json.dumps({'targeted_paths':len(paths),'supplement_rows':len(rows),'errors':errors}),flush=True)
