from pathlib import Path
import json,csv,collections
D=Path(__file__).parent;O=Path((D/'CURRENT_EXPORT.txt').read_text().strip())
report=r'''# NeuFSD 原实验材料交接

本包于 2026-09-21 在现存服务器做只读材料整理。没有训练、重测硬件、修改稿件、push 或提交 HotCRP。包完成不表示五项论文修订完成，更不表示 Shepherd 批准。所有“最终”身份均以证据等级为准，不能以 mtime、目录名或最佳指标代替来源证明。

## 先读这些文件

- `roots_inventory.csv`：双根访问情况、真实路径和观察到的角色。
- `manifest.csv`：每份副本的原路径、realpath、设备/inode、字节数、SHA256、复制方式。
- `path_resolution.csv`：原字面路径、cwd 是否已知、解析候选及存在状态。相对路径不默认用采集 shell 的 cwd。
- `duplicate_conflicts.csv`：A/B 同相对路径，以及 NeuFSD1 与实验工作目录对应源码的内容差异。两个候选均保留。
- `figure_provenance.csv`、`table_provenance.csv`：可见图表候选和来源关系；未确认的投稿编号明确为 unknown。
- `run_configurations.csv`：原 args.json 全字段，方便制作模型/训练附录；原 JSON 也保留。
- `csv_schema_audit.csv`：完整 CSV 的行数、所有列名、窗口范围和负值诊断。没有删除负估计或选取“更好”的列。
- `artifact_identity.csv`、`trace_chunks.csv`：大输入、权重、原归档的 stat 身份和读取限制。没有重新全量 hash 大文件。
- `missing_evidence.csv`：缺项及具体解除条件。
- `PACKAGE_FILES_SHA256.csv`：独立验证整个包中每个文件；`verify_package.py` 可离线校验。

`source/A`、`source/B` 保存完整选定文件；`records/A`、`records/B` 保存最多 128 KiB / 最后 300 个 splitlines 行的日志摘录。日志摘录的 hash 只代表摘录，不冒充完整日志 SHA。终端进度条中的 CR 也被分行为摘录行。`manifest.csv` 的 copy_mode 是权威标记。

## 双根结论与边界

A 给定短路径 `/zhaoguangxiang-data/shiqilong/MRAC` 在本容器返回 ENOENT，但 `/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC` 可读，用户截图及本机路径规则也支持这个挂载对应关系。它不是通过 short-path realpath 证实的同一 inode 别名，故作为明确的挂载候选记录。A 含代码、配置、运行结果、checkpoint、原始输入、交接文档和 Overleaf 目录。

B `/zhaoguangxiang-data-zzzc/shiqilong/MRAC` 可读，realpath 为 `/home/jovyan/zhaoguangxiang-data-zzzc/shiqilong/MRAC`。它含 four-mode 实验结果、counter/data、运行日志及依赖缓存。不能把 B 简化为纯数据目录。

仅搜索了两个 MRAC 项目；未递归搜索 shiqilong 的其他项目。依赖缓存和大 trace/checkpoint 未全文搜索。读取了适用父目录指令；含凭据的父指令原文未传输。没有更改权限或切换身份。A 的 `overleaf/` 及精确 TeX 路径均报 PermissionError(13)。因此本次不能读取实际投稿 TeX、逐图核对 includegraphics 或核对稿件 PDF 的图号和图像 hash。

已有 README/HANDOFF/reference 索引被复用；现存大复现归档仅记录身份，没有为重做历史整理而解包。导出目录新建，未覆盖旧归档。读盘曾停顿在旧 `compare/caida_org/src/Sketchs/DaVinci/fermat.h`；已记录中断并保留成功副本。后续按优先级、超时和预算复制，所有排除/错误见对应 CSV；文件索引是有界候选索引，不是无遗漏的全盘清单。

## 可直接用于 revision 的发现

### 图表来源与版本

A `HANDOFF.md` 明确记录综合比较图从 `zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots_single_latest_imc/` 复制到 Overleaf（原文件约 2058–2062 行）。该目录自己的 metadata、汇总 CSV 和 PDF 与早期 `plots/` 一并保留。证据为“历史交接记录指向”，尚非本次直接核验投稿 PDF。

早期 comprehensive metadata 记录：CAIDA2016 取 selective 校准，CAIDA2018 取 residual，IMC 取 sample-shape，MAWI 取 w0.30 sample-shape。`run_comprehensive_compare.py:411` 的 `load_ours` 实际遍历候选路径及 `METRIC_PAIRS`，按整份 CSV 的平均 WMRD 最小者选择；不是固定 raw 列。保留 candidate 列表、完整候选 CSV、baseline_detail、neufsd_detail、summary 和结果 metadata，不能把此选择过程略去。

single-latest-IMC metadata 指向 `imc_current_oracle_20260630/p50_s2000_e20_full/window_metrics.csv`。精确路径中的完整 CSV 和 summary 可读，已经补收；同目录 args.json 缺失。`run_imc_current_oracle.py` 明说当前窗口采样、用其恢复 FSD 训练、再测试同一当前窗口。HANDOFF 记录 sample_rate=0.5、2000 候选训练例、20 epochs、phi=100。该设置与此前 5 窗、q=.1 的在线实验不同。没有将它替换成新的在线结果；参数证据为交接/代码而非不存在的 args 文件。

参数敏感性和 decoder ablation 在 `perf_eval_20260630`；预训练消融、SFT 策略、残余校准分别有独立目录和绘图脚本。历史文档记录过 rolling 15、展示范围和多次样式更新，不能把同目录所有 PDF 都说成投稿最终图。每份已收 PDF 的 SHA 及候选类别见图表表格。

### 原模型及训练加载链

可见准确率脚本链为 `simulate_sliding_fullstack_online.py` → `simulate_realtime_online.py` 的 `HEADS`、`make_model`、`train_head` → config 的 `model.py`。HEADS 明确为 10 和 1080 两个输出；循环分别实例化完整 CustomViT 并加载两个 checkpoint。这支持两个独立骨干的当前代码路径，没有找到“19 个独立子网络”的运行证据。HANDOFF 的“19 neurons”是稿件输出层表述，不能等同于 19 个网络。

64x64 CustomViT：3 通道，patch16、17 tokens、dim768、12 层、12 heads、mlp_ratio4、qkv_bias=True、CLS 聚合；外接 LayerNorm → Linear(768,1000) → GELU → Dropout(.1) → Linear(1000,out_dim)。128x128 配置另存，不能将 17 tokens 套到全部 run。`setup_imports` 将项目 local_deps 加到 sys.path；该目录内实际存在 timm shim，已复制。该静态加载链与 pip timm 版本声明不同；未找到每个历史进程的 `module.__file__`/代码 SHA 快照，因此不能声称逐 run 动态 import 身份已完全认证。

`src/mrac_data.py` 默认构造 ascending/original/descending 原始 counter 值，但支持 `COUNTER_FEATURE_MODE`、`COUNTER_INPUT_MODE=log1p/log1p_total` 环境覆盖。默认不是所有历史运行的事实；原 args/launcher/log 没记录的覆盖仍为 unknown。

CAIDA2018 avg5 的实际 args 记录 H800、64x64、history_size=5、epochs=5、batch256、lr=.01、sample_rate=.1/seed42、counter seed0..399、avg replicas5、holdout .1，窗口 5..728。与 fair_s2000 交接定义对应时，每 head 候选2000、训练1800/验证200。源码模型在循环外创建、train_head 每次新建 Adam，支持权重连续/优化器重置的现有实现；历史具体源快照仍须关联验证。

### 原 four-dataset prior

`zipf_fsd_release/HANDOFF.md:1335–1384` 列出 6 个 root：两个 synthetic Zipf（caida2016_64_64 / caida2018_64_64，各30个 dataset），以及 CAIDA2016/CAIDA2018/IMC/MAWI 各 first8。counter 索引每 dataset400例。交接命令：config `64_64_caida_org`，20 epochs、batch64、Adam lr=.01、`--val-tail-per-root 3`，两 head 分别 GPU2/3。按这些索引与划分规则推得每 head 总36,800例、训练29,600/验证7,200；这是索引推导，非重新训练的观测。

训练尾日志记录的最佳权重名是 `best_model_25.745088.pth` 和 `best_model_26.394901.pth`；在线 args 记录相同加载路径，现存两个文件大小为345,823,066及350,107,354 bytes。仅 stat、不反序列化、不全量 hash、不装包。它们与接收方24,000例/10epoch synthetic-only prior 是不同来源。

### sampling、counter/heavy 与评分

`simulate_fullstack_online.py` 的标签生成首先从 raw key 计数，再做稳定 whole-flow 采样、以1/q恢复 FSD，并合成 fine stream；所有步骤代码完整保留。运行缓存索引、采样缓存 summary/timing 和 train/test 映射亦保留。

HANDOFF 明确说明旧 IMC/MAWI 的 `EL/heavy_0.csv` 从精确 flow counts（count>=100）生成，并非 C++ ElasticSketch Hot Filter 的实测近似结果（release HANDOFF:1333）。CAIDA 路径不可据此一概判断。现有 evaluator 读取 EL 中 count，神经预测用于 size<=100，尾部由 heavy 分布插值/外推；代码使用 full-stream counter 的入口与 dataplane 原型分开保留。没有宣称它们组成已验证的有限 Hot Filter 端到端 pipeline。

`simulate_realtime_online.py:527–534`：对 clip>=0 的预测 p、真值 t，d=(p+t)/2；MRD=mean(|p-t|/d)（d>0），WMRD=mean(|p-t|)/mean(d)。support 由 `load_true` 读取的1..10与10..10000真值数组决定，需与 parser 产物一起解释；不是默认补齐所有零 bin。small prediction、rounding、heavy插值和各 gate/sample-shape 列均保留。baseline 的 C++ 公式/结果列另存，不用神经公式替它们背书。

baseline 输入还有重要区别：综合 runner 将完整原 key 做 FNV-1a，写13B容器的前4B，其余9B为零，以配合旧 baseline 的4B key路径。该变换有哈希碰撞可能，不能与新服务器完整13B流标识直接认定相同。保留 canonicalize_trace.cpp、baseline 源码、完整 aggregate CSV及成功读取的逐任务原 CSV/JSON。

### 原硬件记录

综合 metadata/forward_timing.json 明确记录 NVIDIA H800、CPU threads112、CPU 23.8354735 ms、H800 4.0439958 ms，backend=`native_vit_fallback:ModuleNotFoundError`。这是原 fallback 两模型前向计时，不能写成精确 timm/shim 模型或接收方4090计时。Xeon Platinum8480+、2 sockets×56cores×2threads 的信息来自 HANDOFF；本次没有重新测量以填历史字段。

Redis/BESS 的原 repeats CSV、summary、manifest 和实现说明已收。manifest 指明 Redis decode=false/query_count=0；BESS64B包+20B L1 overhead。不能把 insertion-only 吞吐称完整神经解码吞吐。

Tofino/DaVinci 存在历史记述冲突：HANDOFF 曾明说 DaVinci 为未本地编译的保守资源模型/线性延迟估算，另一条记录写后来取消 estimate 文案。保留这两段及源代码，缺原编译报告/实测日志时不把措辞变更当成新增测量。P4 compiler、board、版本与逐表原始记录尚未完整核实。

### 输入身份

旧 IMC 原文件 size/13=98,863,335 条（比接收方参考多7），98个完整1M窗；旧 MAWI=114,341,826（比接收方参考多19,230），114窗。交接文档也写了相同计数。未读取大文件做新SHA，不能声称与给定新hash一致或不一致。

CAIDA2016 找到 formatted00..09；格式候选16B、key offset8/len8。formatted01.dat 有1byte余数，未改动。CAIDA2018 可见29个 raw块，counter索引含729个 dataset、shape=[291600,4096]；raw `130000.dat`只是其中一个块，不能用单块大小否定729窗。21B reader使用前13B key，后8B的原始语义尚无足够证据；“代码未使用”不等于证明为零填充或timestamp。旧原pcap筛选规则、完整来源日期/方向与转换工具链仍需对应原parser/清单确认。

## 尚未闭合的核心问题

本包已有较强来源线索和原表格，但尚不能回答“投稿最终每幅图/表”到全部输入、模型hash、历史代码hash的完整链。主要解除条件：可读的实际投稿TeX/PDF和图片副本；oracle缺失args/launcher；每类run当时cwd/环境/module路径快照；完整原输入转换 provenance；checkpoint既有hash或后续授权分发；硬件/compiler原日志。详见 `missing_evidence.csv`，不得把待确认项用新服务器测量填满。
'''
(O/'README.md').write_text(report)
(O/'PATH_MAPPING.md').write_text('''# 路径映射（原文件不改写）

| 原路径前缀 | 包内路径前缀 | 说明 |
|---|---|---|
| /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/ | source/A/ | 实际可读 A |
| /zhaoguangxiang-data/shiqilong/MRAC/ | source/A/ | 仅挂载候选映射；给定短路径本机 ENOENT |
| /zhaoguangxiang-data-zzzc/shiqilong/MRAC/ | source/B/ | 实际可读 B |
| /home/jovyan/zhaoguangxiang-data-zzzc/shiqilong/MRAC/ | source/B/ | B 已核实 realpath 别名 |

日志摘录对应 records/A 或 records/B，扩展名 .tail300.txt。只对 manifest 中存在的文件有副本；大输入和权重不在包内。接收方可用自己的位置建立路径映射，但不能把新输入映射后自动认定为旧图原输入。不要直接执行归档中的旧启动/cleanup脚本。

相对路径如 configs/...、mainonly_runs_20260623/...：只有 launcher 的 cd/cwd 证据才可确定历史绝对路径。当前表中的 conditional_candidate_cwd_unrecorded 是基于目录布局的待确认候选，不是已确认cwd。index.json 的 data_file 则由 mrac_data.py 的 with_name 规则按该索引所在目录解析。外部引用只记录具体路径，不递归扩展父目录。ZIP 内不含符号链接。
''')
missing=[
('G01','final figure/table identity','Overleaf returns PermissionError(13)','Actual submitted TeX/includegraphics and figure copies, or author-exported manuscript manifest with hashes','final figure numbering and paper-source identity remain unknown'),
('G02','historical code/model import identity','current source and logs exist; no per-run commit/module.__file__ attestation','Original launcher/environment/module paths/source snapshot for each final run','static code cannot prove exact code loaded by every historical process'),
('G03','IMC current-window oracle configuration','window_metrics and summary found; args.json ENOENT','Original args/command/log/cwd for p50_s2000_e20_full','use documented q=.5/20epochs only with handoff evidence grade'),
('G04','raw input identity and parser filtering','size/layout indexes available; new-server SHA not compared','Original conversion commands/parser and existing hashes, capture directions/date/part list; clarify CAIDA2018 last8 bytes','old/new traces cannot be declared identical'),
('G05','CAIDA2016 record remainder','formatted01.dat has size mod16=1','Original archive/conversion manifest explaining trailing byte and split policy','do not silently truncate or claim all inputs are record-aligned'),
('G06','checkpoint identity','two matching names exist; hundreds of MB each; no full hash/load performed','Existing checksum + original state_dict/module evidence, or separate model transfer if needed','small ZIP does not reproduce training without omitted large artifacts'),
('G07','Tofino/DaVinci historical resources','handoff contains estimate-versus-measured wording change; raw report not established','Original compiler version/resource reports, board logs, exact source/build flags and measured timing','no claim that estimates became measurements'),
('G08','exact model latency','original H800 timing explicitly native_vit_fallback','Original exact-model timing log if the manuscript claims exact model latency','fallback timing must stay separately labeled'),
('G09','counter/heavy end-to-end semantics','IMC/MAWI heavy documented exact-assisted','Original finite-filter experiment binding counter generation, heavy output, neural evaluation, and resource ledger','do not splice structure prototype into claimed measured pipeline'),
('G10','bounded collection omissions','some files exceed budget/time or shared storage read failed','See excluded_files.csv and collection_errors.csv; retry only listed necessary paths when readable','full baseline aggregate preserved; omitted per-task details explicitly disclosed'),
]
with (O/'missing_evidence.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['gap_id','topic','observed_gap','closure_condition','consequence']);w.writerows(missing)
coverage=[
('resources','Original H800 fallback timing, args GPU name, baseline/deployment CSV and source','G07 G08 G09','Evidence collected; no manuscript resource table added'),
('sampling / label generation','whole-flow code, original caches/indexes, four-dataset prior provenance','G02 G04 G05 G09','Evidence collected; offline exact counting cost is not silently omitted'),
('model / training appendix','full args, two model classes and shim, prior logs and checkpoint paths','G02 G03 G06','Appendix/GitHub parameter sources available; release not published'),
('small-flow objective / metrics','full raw/gate/support code, complete aggregate baseline CSV, canonical key rules','G01 G03 G09','Claim edits remain author decisions'),
('ViT / calibration / presentation','model source, plotting scripts, candidate figure provenance and old handoff','G01 G02 G07','No Table1 deletion, manuscript edit, or Shepherd approval performed')]
with (O/'revision_evidence_coverage.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['revision_topic','available_evidence','gap_ids','completion_scope']);w.writerows(coverage)
print('README, path mapping, gap table, revision coverage written')
