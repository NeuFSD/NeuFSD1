"""Read-only bounded collection. Does not execute project code or deserialize models."""
from pathlib import Path
import csv, hashlib, json, os, re, stat, subprocess, time, signal

DEST = Path(__file__).parent
OUT = Path((DEST / 'CURRENT_EXPORT.txt').read_text().strip())
ROOTS = {'A': Path('/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC'),
         'B': Path('/zhaoguangxiang-data-zzzc/shiqilong/MRAC')}
TEXT_EXT = {'.py','.c','.cpp','.h','.hpp','.sh','.md','.txt','.json','.csv','.yaml','.yml','.p4','.tex','.bib','.cfg','.ini','.toml'}
manifest, excluded, errors = [], [], []
def write_csv(name, rows, fields=None):
    if fields is None: fields = list(rows[0]) if rows else ['status']
    with (OUT/name).open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=fields);w.writeheader();w.writerows(rows)

def tail_bytes(p, max_bytes=131072, lines=300):
    with p.open('rb') as f:
        f.seek(0,2); size=f.tell(); f.seek(max(0,size-max_bytes)); data=f.read()
    if size>max_bytes: data=data.split(b'\n',1)[-1]
    return b'\n'.join(data.splitlines()[-lines:])+b'\n'

paths=set()
for name in ['A_shallow_file_index.txt','A_target_index.txt','A_run_index.txt','A_final_index.txt','B_shallow_file_index.txt','B_run_index.txt']:
    p=OUT/'records'/name
    if p.exists(): paths.update(p.read_text().splitlines())
for rid,root in ROOTS.items():
    for rel in ['AGENTS.md','HANDOFF.md','README.md','review.md','review_action_items.md','zipf_fsd_release/HANDOFF.md','zipf_fsd_release/README.md','zipf_fsd_release/.gitignore','zipf_fsd_release/requirements.txt']:
        if (root/rel).is_file(): paths.add(str(root/rel))

def priority(s):
    p=Path(s)
    if s.startswith(str(ROOTS['B'])): return 0
    if p.name in {'HANDOFF.md','metadata.json','args.json','manifest.json','baseline_detail.csv','neufsd_detail.csv','summary_compare.csv','summary_compare_latest_imc.csv','forward_timing.json','window_metrics.csv','summary.csv','summary_all.csv'}: return 1
    if '/zipf_fsd_release/scripts/' in s or '/zipf_fsd_release/local_deps/' in s or '/zipf_fsd_release/src/' in s: return 2
    if '/configs/' in s or '/final_memory_sweep_10x/' in s: return 3
    if p.suffix in {'.csv','.json','.log'}:return 4
    return 5
def timeout_handler(signum,frame): raise TimeoutError('per-file shared filesystem timeout')
signal.signal(signal.SIGALRM,timeout_handler)
realroots={r:root.resolve() for r,root in ROOTS.items()}
total=0;started=time.monotonic()
journal=(OUT/'records/manifest_incremental.jsonl').open('w')
for s in sorted(paths,key=lambda s:(priority(s),s)):
    p=Path(s)
    rid=next((r for r,root in ROOTS.items() if p.is_relative_to(root)),None)
    if rid is None: continue
    rel=p.relative_to(ROOTS[rid]); parts=rel.parts
    if any(x.startswith(('.git','.cache','.config','.tmp','.pycache','.codex-transfer','__pycache__')) and x!='.gitignore' for x in parts): continue
    if p.name=='AGENTS.md': continue  # parent instructions contain credentials; do not transmit
    if p.name=='heavy_0.csv' or '10_1e4_real' in parts or '1_10_real' in parts: continue
    islog=p.suffix=='.log'
    if p.suffix not in TEXT_EXT|{'.pdf','.log'} and p.name not in {'.gitignore','Makefile'}: continue
    if p.suffix=='.pdf' and not any(x in s for x in ['/plots/','/plots_', '/reproduced_figures/','final_memory_sweep_10x']): continue
    if time.monotonic()-started>210:
        excluded.append({'root_id':rid,'relative_path':str(rel),'reason':'bounded collection time budget; see preserved aggregate CSVs','size_bytes':''});continue
    if str(rel)=='zipf_fsd_release/compare/caida_org/src/Sketchs/DaVinci/fermat.h':
        excluded.append({'root_id':rid,'relative_path':str(rel),'reason':'previous read stalled in kernel disk wait; not retried','size_bytes':''});continue
    try:
        signal.setitimer(signal.ITIMER_REAL,3)
        st=p.stat()
        if not stat.S_ISREG(st.st_mode): continue
        real=p.resolve()
        if not any(real.is_relative_to(root) for root in realroots.values()):
            excluded.append({'root_id':rid,'relative_path':str(rel),'reason':'external symlink; ownership unverified','size_bytes':st.st_size});continue
        if st.st_size>5_000_000 and not islog:
            excluded.append({'root_id':rid,'relative_path':str(rel),'reason':'individual small-file limit 5 MB','size_bytes':st.st_size});continue
        target=Path('records' if islog else 'source')/rid/rel
        if islog: target=Path(str(target)+'.tail300.txt')
        dst=OUT/target
        data=dst.read_bytes() if dst.is_file() else tail_bytes(p) if islog else p.read_bytes()
        if p.suffix in TEXT_EXT|{'.log'}:
            decoded=data.decode('utf-8',errors='replace')
            if re.search(r'(?:accessSecret|accessKeyID|api[_-]?key|password)\s*[=:]\s*[\"\x27]?[A-Za-z0-9+/=_-]{12,}',decoded,re.I):
                excluded.append({'root_id':rid,'relative_path':str(rel),'reason':'potential credential assignment; withheld entire file','size_bytes':st.st_size});continue
        if total+len(data)>150_000_000:
            excluded.append({'root_id':rid,'relative_path':str(rel),'reason':'uncompressed collection budget','size_bytes':st.st_size});continue
        if not dst.is_file():dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
        st2=p.stat()
        manifest.append({'root_id':rid,'original_path':str(p),'relative_path':str(rel),'realpath':str(real),'device':st.st_dev,'inode':st.st_ino,'source_size_bytes':st.st_size,'mtime_ns_clue_only':st.st_mtime_ns,'package_path':str(target),'package_size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'copy_mode':'tail_300_lines_max_128KiB' if islog else 'full','source_unchanged_during_copy':st.st_size==st2.st_size and st.st_mtime_ns==st2.st_mtime_ns,'paper_identity':'candidate; see provenance report'})
        total+=len(data)
        journal.write(json.dumps(manifest[-1])+'\n');journal.flush()
    except OSError as e: errors.append({'path':str(p),'error':repr(e)})
    finally:signal.setitimer(signal.ITIMER_REAL,0)
journal.close()
write_csv('manifest.csv',manifest)
write_csv('excluded_files.csv',excluded,['root_id','relative_path','reason','size_bytes'])
write_csv('collection_errors.csv',errors,['path','error'])
(OUT/'records/collection_summary.json').write_text(json.dumps({'files':len(manifest),'bytes_uncompressed':total,'excluded':len(excluded),'errors':len(errors),'timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2))
print(json.dumps({'files':len(manifest),'bytes':total,'excluded':len(excluded),'errors':len(errors)}),flush=True)
