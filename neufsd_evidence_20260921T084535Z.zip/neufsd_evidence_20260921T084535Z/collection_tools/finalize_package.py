from pathlib import Path
import csv,json,os,hashlib,zipfile,stat,shutil,subprocess,re,time
D=Path(__file__).parent;O=Path((D/'CURRENT_EXPORT.txt').read_text().strip())
def write(name,rows,fields=None):
 if fields is None:fields=list(rows[0]) if rows else ['status']
 with (O/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
with (O/'manifest.csv').open() as f:manifest=list(csv.DictReader(f))
known={r['package_path'] for r in manifest}
# Index only our output, not a source-tree rescan. Recover already copied files from the interrupted pass.
r=subprocess.run(['rg','--files','--hidden','--no-ignore',str(O/'source'),str(O/'records/A'),str(O/'records/B')],capture_output=True,text=True,check=True)
roots={'A':Path('/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC'),'B':Path('/zhaoguangxiang-data-zzzc/shiqilong/MRAC')}
recovered=0
for s in r.stdout.splitlines():
 p=Path(s);rel=p.relative_to(O);key=str(rel)
 if key in known:continue
 parts=rel.parts;rid=parts[1];original=Path(*parts[2:]);islog=str(original).endswith('.tail300.txt')
 if islog:original=Path(str(original).removesuffix('.tail300.txt'))
 data=p.read_bytes()
 manifest.append(dict(root_id=rid,original_path=str(roots[rid]/original),relative_path=str(original),realpath='not re-resolved; recovered preserved copy',device='',inode='',source_size_bytes='',mtime_ns_clue_only='',package_path=key,package_size_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),copy_mode='tail_300_lines_max_128KiB' if islog else 'full',source_unchanged_during_copy='unknown; copied before interrupted manifest flush',paper_identity='candidate; see provenance report'));recovered+=1
write('manifest.csv',manifest)
subprocess.run(['python3',str(D/'build_evidence_tables.py')],check=True)
with (O/'manifest.csv').open() as f:manifest=list(csv.DictReader(f))
copied={(r['root_id'],r['relative_path']) for r in manifest}
with (O/'excluded_files.csv').open() as f:excluded=list(csv.DictReader(f))
excluded=[r for r in excluded if (r['root_id'],r['relative_path']) not in copied];write('excluded_files.csv',excluded,['root_id','relative_path','reason','size_bytes'])
# Final audit summaries are derived only from copied records.
counts=collections_counts={}
for rid in ['A','B']:counts[rid]=sum(r['root_id']==rid for r in manifest)
critical=[
'source/A/HANDOFF.md','source/A/zipf_fsd_release/HANDOFF.md',
'source/A/zipf_fsd_release/scripts/simulate_realtime_online.py',
'source/A/zipf_fsd_release/scripts/simulate_sliding_fullstack_online.py',
'source/A/zipf_fsd_release/scripts/train_pretrain.py',
'source/A/zipf_fsd_release/scripts/run_comprehensive_compare.py',
'source/A/zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py',
'source/A/zipf_fsd_release/local_deps/timm/models/vision_transformer.py',
'source/A/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/baseline_detail.csv',
'source/A/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/neufsd_detail.csv',
'source/A/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/metadata.json',
'source/A/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots_single_latest_imc/metadata.json',
'source/A/zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/p50_s2000_e20_full/window_metrics.csv',
'records/A/zipf_fsd_release/mainonly_runs_20260623/pretrain_fourdatasets/logs/pretrain_1_10.log.tail300.txt',
'records/A/zipf_fsd_release/mainonly_runs_20260623/pretrain_fourdatasets/logs/pretrain_10_1e4.log.tail300.txt',
'source/A/final_memory_sweep_10x/manifest.json']
missing=[s for s in critical if not (O/s).is_file()]
if missing:raise RuntimeError('Critical intended evidence not collected: '+repr(missing))
for name in ['collect_evidence.py','supplement_evidence.py','copy_final_sources.py','build_evidence_tables.py','write_evidence_report.py','finalize_package.py']:
 dst=O/'collection_tools'/name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(D/name,dst)
verify='''from pathlib import Path
import csv,hashlib
root=Path(__file__).resolve().parent
errors=[];count=0
with (root/'PACKAGE_FILES_SHA256.csv').open() as f:
 for row in csv.DictReader(f):
  p=root/row['path'];count+=1
  if not p.is_file() or p.is_symlink():errors.append(row['path']+': missing/not regular');continue
  data=p.read_bytes()
  if len(data)!=int(row['bytes']) or hashlib.sha256(data).hexdigest()!=row['sha256']:errors.append(row['path']+': mismatch')
print({'checked_files':count,'errors':errors})
raise SystemExit(bool(errors))
'''
(O/'verify_package.py').write_text(verify)
summary={'source_files_by_root':counts,'manifest_files':len(manifest),'recovered_copies_from_interrupted_pass':recovered,'uncompressed_source_and_log_bytes':sum(int(r['package_size_bytes']) for r in manifest),'excluded_candidates':len(excluded),'required_evidence_present':True,'source_writes':False,'experiments_run':False,'paper_revision_complete':False,'shepherd_approval_claimed':False,'hash_scope':'PACKAGE_FILES_SHA256 excludes itself; external ZIP SHA256 covers the whole ZIP'}
(O/'COLLECTION_STATUS.json').write_text(json.dumps(summary,indent=2))
# Do not include redundant mutable execution journals or PID files in the final ZIP.
skip={'records/manifest_incremental.jsonl','records/supplement_manifest.json','records/collector_pid.txt','records/collector_resume_pid.txt'}
allfiles=subprocess.run(['rg','--files','--hidden','--no-ignore',str(O)],capture_output=True,text=True,check=True).stdout.splitlines()
files=[];hashes=[];symlinks=[];sensitive=[]
for s in sorted(allfiles):
 p=Path(s);rel=str(p.relative_to(O))
 if rel in skip or rel=='PACKAGE_FILES_SHA256.csv':continue
 if p.is_symlink():symlinks.append(rel);continue
 data=p.read_bytes()
 if p.suffix in {'.py','.sh','.md','.txt','.json','.yaml','.yml'} and re.search(rb'(?:accessSecret|accessKeyID)\s*[=:]\s*[\"\x27]?[A-Za-z0-9+/=_-]{12,}',data,re.I):sensitive.append(rel)
 files.append(p);hashes.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
if symlinks or sensitive:raise RuntimeError('Package review needed: '+repr({'symlinks':symlinks,'sensitive_assignment_files':sensitive}))
write('PACKAGE_FILES_SHA256.csv',hashes,['path','bytes','sha256']);files.append(O/'PACKAGE_FILES_SHA256.csv')
zip_path=O.with_suffix('.zip');temporary=Path(str(zip_path)+'.partial')
if zip_path.exists():raise RuntimeError('Refusing to overwrite existing ZIP')
with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,arcname=str(Path(O.name)/p.relative_to(O)))
size=temporary.stat().st_size
if size>100_000_000:raise RuntimeError(f'ZIP exceeds 100 MB: {size}')
with zipfile.ZipFile(temporary) as z:
 bad=z.testzip()
 if bad:raise RuntimeError('ZIP CRC error: '+bad)
 assert not any(stat.S_ISLNK(i.external_attr>>16) for i in z.infolist())
 for row in hashes:
  data=z.read(O.name+'/'+row['path'])
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
temporary.rename(zip_path);digest=hashlib.sha256(zip_path.read_bytes()).hexdigest()
Path(str(zip_path)+'.sha256').write_text(digest+'  '+zip_path.name+'\n')
result=summary|{'zip_path':str(zip_path),'zip_bytes':size,'limit_bytes':100_000_000,'zip_sha256':digest,'zip_crc_verified':True,'zip_member_sha256_verified':len(hashes),'no_zip_symlinks':True}
Path(str(zip_path)+'.verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
