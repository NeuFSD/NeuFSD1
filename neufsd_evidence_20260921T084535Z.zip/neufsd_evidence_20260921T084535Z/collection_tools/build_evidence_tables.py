from pathlib import Path
import csv,json,os,re,hashlib,collections,stat
DEST=Path(__file__).parent; OUT=Path((DEST/'CURRENT_EXPORT.txt').read_text().strip())
A=Path('/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC'); B=Path('/zhaoguangxiang-data-zzzc/shiqilong/MRAC')
ROOTS={'A':A,'B':B};REAL={r:p.resolve() for r,p in ROOTS.items()}
def write(name,rows,fields=None):
    if fields is None:fields=list(rows[0]) if rows else ['status']
    with (OUT/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def read(name):
    with (OUT/name).open() as f:return list(csv.DictReader(f))
manifest=read('manifest.csv')
manifest.extend(json.loads((OUT/'records/supplement_manifest.json').read_text()))
manifest=list({r['package_path']:r for r in manifest}.values());write('manifest.csv',manifest)
by_path={r['package_path']:r for r in manifest}
inventory=[]
for rid,original,actual,role,evidence in [
('A','/zhaoguangxiang-data/shiqilong/MRAC',A,'code/configs/manuscript directory/results/prior/checkpoints/raw inputs','HANDOFF; zipf_fsd_release/scripts, mainonly_runs_20260623; Overleaf PermissionError'),
('B','/zhaoguangxiang-data-zzzc/shiqilong/MRAC',B,'runtime results/counter stores/raw data/dependency caches','four_mode_runs_local_h800_20260617; data_full; python_deps; not assumed data-only')]:
    top=[]
    with os.scandir(actual) as it:
        for i,e in enumerate(it):
            if i>=100:break
            top.append(e.name)
    inventory.append({'root_id':rid,'original_path':original,'accessible_path':str(actual),'realpath':str(actual.resolve()),'access_status':'short path ENOENT; /home/jovyan path readable' if rid=='A' else 'readable','major_children':';'.join(top),'observed_roles':role,'evidence':evidence,'alias_limit':'A short prefix is a documented mount candidate, not a verified filesystem symlink' if rid=='A' else 'short path realpath equals /home/jovyan mount'})
write('roots_inventory.csv',inventory)

resolution=read('links_resolution.csv');stats={}
def stat_path(p):
    key=str(p)
    if key in stats:return stats[key]
    try:
        st=p.stat();v=(True,str(p.resolve()),'exists')
    except OSError as e:v=(False,str(p),'access_error:'+repr(e))
    stats[key]=v;return v
def add_ref(row,field,literal,cwd='',base=None,reason=''):
    if not literal or not isinstance(literal,str):return
    if '\n' in literal or len(literal)>2000:return
    rid=row['root_id'];p=Path(literal);status='';candidate=''
    if literal.startswith(('http:','https:')):return
    if '$' in literal or '*' in literal or '{' in literal:
        status='unresolved_template_no_eval'
    elif p.is_absolute():candidate=str(p);status='absolute_recorded'
    elif base is not None:candidate=str(base/p);status='file_relative_semantics'
    else:
        candidate=str(ROOTS[rid]/'zipf_fsd_release'/p);status='conditional_candidate_cwd_unrecorded'
    exists='not_checked';real='';scope=rid
    if candidate:
        cp=Path(candidate)
        if candidate.startswith('/zhaoguangxiang-data/shiqilong/MRAC/'):
            cp=A/candidate.removeprefix('/zhaoguangxiang-data/shiqilong/MRAC/');candidate=str(cp);status+=';mount_candidate'
        belongs=any(cp.is_relative_to(root) or cp.is_relative_to(REAL[r]) for r,root in ROOTS.items())
        if belongs:exists,real,err=stat_path(cp);status+=';'+err;scope=next((r for r,root in ROOTS.items() if cp.is_relative_to(root) or cp.is_relative_to(REAL[r])),rid)
        else:scope='external_reference';status+=';exact_reference_not_opened';exists='not_checked';real=''
    resolution.append(dict(referring_file=row['original_path'],field_or_line=field,literal_path=literal,recorded_cwd=cwd or 'unknown (not current shell cwd)',resolved_candidate=candidate,root_id=scope,realpath=real,exists=exists,resolution_status=status,evidence=reason or row['package_path']))
def walk_json(value,prefix=''):
    if isinstance(value,dict):
        for k,v in value.items():yield from walk_json(v,prefix+'.'+k if prefix else k)
    elif isinstance(value,list):
        for i,v in enumerate(value):yield from walk_json(v,f'{prefix}[{i}]')
    elif isinstance(value,str):yield prefix,value
args_rows=[]
for row in manifest:
    rel=row['relative_path'];p=OUT/row['package_path'];name=Path(rel).name
    if name not in {'args.json','metadata.json','manifest.json','index.json','sample_cache_summary.json'}:continue
    if int(row['package_size_bytes'])>1_000_000:continue
    try:d=json.loads(p.read_text())
    except (ValueError,UnicodeError):continue
    if name=='args.json':
        args_rows.append({'root_id':row['root_id'],'run':str(Path(rel).parent),'args_package_path':row['package_path'],'parameters_json':json.dumps(d,ensure_ascii=False,sort_keys=True),'historical_code_hash':'unknown; current source SHA is not runtime provenance'})
    for field,value in walk_json(d):
        if '/' in value or field.rsplit('.',1)[-1] in {'data_file','config_dir','data_full_root'}:
            base=Path(row['original_path']).parent if name=='index.json' and field=='data_file' else None
            add_ref(row,field,value,base=base,reason=('mrac_data.py uses Path(index_path).with_name(index[data_file])' if base else 'literal from '+row['package_path']+'; relative root is a candidate until launcher cwd is proven'))
# Preserve scoped path-bearing evidence in handoff/source, without resolving shell expressions.
for row in manifest:
    if Path(row['relative_path']).name not in {'HANDOFF.md','run_four_mode_experiments.sh','run_full.sh','run_comprehensive_compare.py','plot_comprehensive_single_latest_imc.py'}:continue
    text=(OUT/row['package_path']).read_text(errors='replace')
    for i,line in enumerate(text.splitlines(),1):
        for literal in re.findall(r'/(?:home/jovyan/)?zhaoguangxiang-data(?:-zzzc)?/shiqilong/MRAC[^\s`\"\x27<>]*',line):
            add_ref(row,f'line {i}',literal.rstrip('.,);'),reason=row['package_path']+f':{i}; document/source reference, not proof of run use')
write('path_resolution.csv',resolution,['referring_file','field_or_line','literal_path','recorded_cwd','resolved_candidate','root_id','realpath','exists','resolution_status','evidence'])
write('run_configurations.csv',args_rows,['root_id','run','args_package_path','parameters_json','historical_code_hash'])

groups=collections.defaultdict(list)
for r in manifest:
    if r['copy_mode']=='full':groups[r['relative_path']].append(r)
conf=[]
def conflict(group,rs,kind):
    hashes={r['sha256'] for r in rs};physical={(str(r['device']),str(r['inode'])) for r in rs}
    for r in rs:conf.append({'comparison_group':group,'comparison_kind':kind,'root_id':r['root_id'],'relative_path':r['relative_path'],'sha256':r['sha256'],'associated_run':'path-scoped; no historical source snapshot attestation','comparison_result':'same_physical_file' if len(physical)==1 else 'same_content' if len(hashes)==1 else 'different_content','adoption_basis':'retain all candidates; no automatic final-version selection','package_path':r['package_path']})
for group,rs in groups.items():
    if len({r['root_id'] for r in rs})>1:conflict(group,rs,'same_relative_path_A_B')
for r in manifest:
    if r['root_id']=='A' and r['relative_path'].startswith('NeuFSD1/experiments/'):
        peer='source/A/zipf_fsd_release/'+r['relative_path'].removeprefix('NeuFSD1/experiments/')
        if peer in by_path and Path(peer).suffix in {'.py','.sh','.c','.cpp','.h','.csv','.json'}:conflict(r['relative_path'],[r,by_path[peer]],'public_checkout_vs_experiment_worktree')
write('duplicate_conflicts.csv',conf,['comparison_group','comparison_kind','root_id','relative_path','sha256','associated_run','comparison_result','adoption_basis','package_path'])

# Complete headers/row counts and negative-number diagnostics: no columns are rewritten.
csv_rows=[]
for row in manifest:
    p=OUT/row['package_path']
    if p.suffix!='.csv' or '/tasks/' in row['relative_path']:continue
    if not any(s in row['relative_path'] for s in ['comprehensive_compare_20260630','final_e5','p50_s2000_e20_full','perf_eval_20260630','final_memory_sweep_10x']):continue
    try:
        with p.open() as f:
            reader=csv.DictReader(f);headers=reader.fieldnames or [];count=0;negative=collections.Counter();mins={};maxs={}
            for x in reader:
                count+=1
                for k,v in x.items():
                    if k is None:continue
                    try:val=float(v)
                    except (ValueError,TypeError):continue
                    if val<0:negative[k]+=1
                    if k=='minute':mins[k]=min(mins.get(k,val),val);maxs[k]=max(maxs.get(k,val),val)
        csv_rows.append({'package_path':row['package_path'],'row_count':count,'columns_json':json.dumps(headers),'negative_values_by_column_json':json.dumps(negative),'minute_min':mins.get('minute',''),'minute_max':maxs.get('minute',''),'interpretation':'negative numeric values preserved; counts are diagnostics, not error judgments'})
    except (OSError,UnicodeError,csv.Error):pass
write('csv_schema_audit.csv',csv_rows,['package_path','row_count','columns_json','negative_values_by_column_json','minute_min','minute_max','interpretation'])

figure_rows=[]
families=[
('comprehensive_compare_20260630/plots_single_latest_imc','comprehensive comparison single panels','plot_comprehensive_single_latest_imc.py; run_comprehensive_compare.py','metadata.json; summary_compare_latest_imc.csv; baseline_detail.csv; p50_s2000_e20_full/window_metrics.csv','HANDOFF.md:2058-2062 says copied to Overleaf; actual submitted TeX/PDF match blocked'),
('comprehensive_compare_20260630/plots/','comprehensive comparison earlier panels','run_comprehensive_compare.py','metadata.json; baseline_detail.csv; neufsd_detail.csv; original selected CSVs','earlier candidate, retained alongside single-panel variant'),
('perf_eval_20260630/plots/','lambda/phi sensitivity and decoder ablation','perf_eval_sweeps_and_plots.py; perf_eval_first50_runner.py','summary_all.csv; sweeps/*.csv; ablations/decoder_ablation_detail.csv; runs/*/args.json','HANDOFF describes 32 PDFs copied to Overleaf; submitted identity unverified'),
('residual_calibration_20260629/','residual calibration','plot_residual_calibration_paper.py','plot summary CSV and original final_e5 raw/gate CSVs','handoff plus script candidate'),
('sft_strategy_comparison_20260629/','Last/Window5/Avg5 comparison','plot_sft_strategy_comparison.py','plot summary CSV; final_e5 args and window_metrics','handoff plus script candidate'),
('ablation_continuous_pretrain_20260628/','pretrain/continuous SFT ablation','plot_pretrain_sft_ablation.py','onetime/scratch/pretrain CSVs; command in HANDOFF','multiple styling/smoothing candidates; no newest-file selection'),
('final_memory_sweep_10x/','Redis/BESS deployment','plot_redis_bess_deployment.py','manifest.json; full repeats and summary CSVs','raw deployment input; Overleaf redraw is a separate rendering'),
]
for row in manifest:
    if not row['package_path'].endswith('.pdf'):continue
    match=next((x for x in families if x[0] in row['relative_path']),None)
    if match:
        _,family,script,raw,status=match
    else:family='other retained candidate';script='see corresponding scripts and handoff';raw='not individually resolved';status='unknown final figure identity'
    figure_rows.append({'figure_package_path':row['package_path'],'sha256':row['sha256'],'family':family,'script_candidates':script,'raw_config_evidence':raw,'submitted_figure_number':'unknown: submitted manuscript inaccessible','provenance_status':status})
write('figure_provenance.csv',figure_rows,['figure_package_path','sha256','family','script_candidates','raw_config_evidence','submitted_figure_number','provenance_status'])
write('table_provenance.csv',[
{'table_family':'baseline accuracy/resource summaries','candidate_source':'comprehensive_compare_20260630/summary_compare.csv; plots_single_latest_imc/summary_compare_latest_imc.csv','status':'full CSVs preserved; submitted table number unknown'},
{'table_family':'Tofino resources and latency','candidate_source':'A/HANDOFF.md; NeuFSD-p4-main sources and profiling scripts','status':'DaVinci estimate/measured wording conflict in handoff; compiler/hardware original report not established'},
{'table_family':'model/training appendix','candidate_source':'run_configurations.csv; model.py; train_pretrain.py; prior logs/indexes','status':'evidence available, no paper edit performed'},
{'table_family':'Table 1','candidate_source':'A/HANDOFF.md discusses removals/wording','status':'actual submitted TeX inaccessible; deletion not performed'}])
print(json.dumps({'manifest_files':len(manifest),'path_rows':len(resolution),'run_configs':len(args_rows),'conflict_rows':len(conf),'figure_rows':len(figure_rows),'csv_audits':len(csv_rows)}))
