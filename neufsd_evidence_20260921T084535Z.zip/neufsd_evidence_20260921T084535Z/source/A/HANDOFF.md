# MRAC Handoff

Last updated: 2026-07-04 PDT.

## 2026-07-04 Latest Note

### Overleaf Follow-up: Move Extra Citations into Main Text

User asked to move the added references out of the appendix and place them only
in `Introduction` and `Background`; page length is allowed to grow.

Completed:

- Removed the first paragraph under:

```text
overleaf/appendix-KDD.tex
Supplementary Results for Parameter Sensitivity and Decoder Ablation
```

- `appendix-KDD.tex` now has zero `\cite{...}` commands.
- Moved the 37 previously appendix-only references into the main text:
  - Introduction now cites classical streaming summaries, compact counter
    sketches, distribution synopses, and high-speed measurement systems.
  - Background/Related Work now cites reversible/invertible sketches, compact
    hash tables, counter-sharing structures, unbiased updates, spread
    estimators, programmable telemetry, compact counter encodings, and stable
    large-scale summaries.
- The actual compile entry still has exactly 60 unique references, all from
  `overleaf/Reference.bib`.

Validation:

```bash
cd /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf
export PATH=/home/stallone1/texlive/2024/bin/x86_64-linux:$PATH
latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode -halt-on-error %O %S' NeuFSD-sigmetrics.tex
```

Result:

```text
NeuFSD-sigmetrics.pdf generated successfully.
bibcite count: 60.
NeuFSD-sigmetrics.tex citation keys: 60.
appendix-KDD.tex citation keys: 0.
No undefined citation/reference/fatal LaTeX errors in checked logs.
Conclusion moved to page 21 because the main text is now longer; user explicitly
said not to worry about page length for this edit.
```

### Overleaf Revision: Citations, Appendix Order, and Math Wording

Current workspace:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC
```

Do not use any `-zzzc` path.

Completed in this phase:

- Updated the latest Overleaf source in:

```text
overleaf/NeuFSD-sigmetrics.tex
overleaf/appendix-KDD.tex
```

- Citation count is now exactly 60 unique references for the actual compile
  entry `NeuFSD-sigmetrics.tex` and its included appendix. All 60 citation keys
  exist in the current `overleaf/Reference.bib`.
- Moved the old appendix section `Additional Evaluation Figures` before
  `Proofs and Details for Section 4`, and retitled it to:

```text
Supplementary Results for Parameter Sensitivity and Decoder Ablation
```

- Added detailed appendix analysis for the full Section 5.2/5.3 supplementary
  figures:
  - replacement threshold `lambda`;
  - hot-flow splice threshold `phi`;
  - decoder accuracy ablation;
  - decoder training/decoding cost ablation.
- Kept the full supplementary figure groups and labels:

```text
fig:lambda_sensitivity_full
fig:phi_sensitivity_full
fig:decoder_ablation_accuracy_full
fig:decoder_ablation_efficiency_full
```

- Lightly copyedited the mathematical analysis wording in the main text and
  appendix so it reads as normal design reasoning rather than as an explicit
  response to reviewer wording. The math content was not changed.

Validation performed:

```bash
cd /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf
export PATH=/home/stallone1/texlive/2024/bin/x86_64-linux:$PATH
latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode -halt-on-error %O %S' NeuFSD-sigmetrics.tex
```

Result:

```text
NeuFSD-sigmetrics.pdf generated successfully.
Output written on NeuFSD-sigmetrics.pdf (37 pages).
thebibliography{60}
No undefined citation/reference/fatal LaTeX errors in the checked logs.
sec:conclusion is still on page 20.
Appendix B = supplementary parameter/ablation results.
Appendix C = proofs and details for Section 4.
```

Known remaining warnings are existing ACM/format warnings, image-description
warnings, PDF-version inclusion warnings, and local `\vspace` warnings. They did
not block compilation.

## 2026-07-01 Latest Note

### Paper/P4/Data-plane Bundle Update

Current workspace remains:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC
```

Do not use any `-zzzc` path.

Completed in this phase:

- Updated `overleaf/NeuFSD-sigmetrics.tex` so every `figure`/`figure*`
  environment has `\setlength{\abovecaptionskip}{-0cm}` immediately after the
  begin line. Static check reports no missing figure caption spacing.
- Added DaVinci Sketch to the Tofino hardware discussion:
  - New P4 resource model: `NeuFSD-p4-main/p4/davinci.p4`.
  - `NeuFSD-p4-main/script/collect_resource_usage.sh` now includes `davinci`
    and uses `mkdir -p`.
  - `NeuFSD-p4-main/README.md` documents that `davinci.p4` is a conservative
    resource model and has not been compiled in this workspace because
    `bf-p4c`/`p4c-tofino`/`p4c` are not available.
  - Table `tofino_resource` now includes `DaVinci^\dagger` with estimated
    resources: 16 stages, 8.95% SRAM, 0% TCAM, 4.84% hash bits, 12.50%
    stateful ALU.
  - Table `tofino_latency` now includes `DaVinci^\dagger` with estimated
    latency 458.83 ns.
  - Latency estimate method in the paper: fit `T(s)=alpha+beta*s` on measured
    rows MRAC/NeuFSD/Sample/Elastic. Least-squares gives
    `alpha=247.76 ns`, `beta=13.19 ns/stage`; DaVinci resource model maps to
    16 stages, so `T(16)=458.83 ns`.
  - Resource estimate method in the paper: count register-array bits,
    independent hash blocks, and stateful read-modify-write blocks in the
    DaVinci P4 resource model, then normalize against compiler-report
    categories from the measured P4 implementations. This is marked as an
    estimate, not a fresh compiler report.
- Created reviewer follow-up checklist:

```text
review_action_items.md
```

  It maps remaining work to original `review.md` comments, including Hot Filter
  proof rigor, decoder generalization, online label cost, retraining frequency,
  window-size sensitivity, lambda/phi overhead sensitivity, decode-speed
  fairness, and terminology/presentation cleanup.
- Created C++ deployment bundle for the next Redis/BESS agent:

```text
dataplane_algorithms_cpp/
```

  Important files:

```text
dataplane_algorithms_cpp/README.md
dataplane_algorithms_cpp/include/sample_dataplane.hpp
dataplane_algorithms_cpp/include/neufsd_dataplane.hpp
dataplane_algorithms_cpp/smoke_test.cpp
dataplane_algorithms_cpp/original/Sketchs/MRAC/MRAC.h
dataplane_algorithms_cpp/original/Sketchs/elastic/ElasticSketch.h
dataplane_algorithms_cpp/original/Sketchs/DaVinci/DaVinci.h
dataplane_algorithms_cpp/original/neufsd/src/gen_counter_store.c
dataplane_algorithms_cpp/original/neufsd/config_64_64_caida_2016/el.h
```

  The `original/` tree preserves experiment code. The `include/` headers are
  lightweight C++17 deployment-oriented interfaces. `NeuFSDDataPlane` only
  implements Hot Filter + cold counter array; neural decoding and calibration
  remain control-plane operations.

Validation performed:

```bash
g++ -std=c++17 -O2 -I dataplane_algorithms_cpp/include \
  dataplane_algorithms_cpp/smoke_test.cpp -o /tmp/mrac_dataplane_smoke
/tmp/mrac_dataplane_smoke
# output: dataplane smoke ok
```

Also checked:

```text
missing figure abovecaptionskip: []
```

Not validated locally:

- Tofino P4 compile/resource report for `davinci.p4`, because no P4/Tofino
  compiler is installed in this workspace.
- LaTeX PDF compile, because neither `latexmk` nor `pdflatex` is installed in
  this workspace.

Follow-up cleanup after user note:

- `dataplane_algorithms_cpp/` is intended to be copied to another server, so it
  must not contain this server's absolute paths or parent-project paths.
- Removed upstream hard-coded paths such as `/home/lzx/...`, `/root/...`,
  `/share/...`, and `/data/...` from
  `dataplane_algorithms_cpp/original/common_func.h`; they now use relative
  `data/...` placeholders.
- Removed the `zipf_fsd_release/...` source-directory reference from
  `dataplane_algorithms_cpp/README.md`.
- Verification command:

```bash
rg -n '(/home/|/root/|/share/|/mnt/|/data/|zhaoguangxiang|shiqilong|zipf_fsd_release|stallone|zzzc|ERSketch)' dataplane_algorithms_cpp
# no output
```

- Re-ran the lightweight C++ smoke test after cleanup; output remains
  `dataplane smoke ok`.

### Redis/BESS Deployment Figure and Paper Update

User provided deployment results in:

```text
final_memory_sweep_10x/
```

Completed:

- Redrew Redis and BESS deployment figures with the local sketch-paper style.
  Each `(algorithm, memory)` point is shown as a grouped boxplot over 10 repeats.
  Outputs:

```text
overleaf/Figure-FSD/perf-eval/software-deploy/redis_events_memory_boxplot.pdf
overleaf/Figure-FSD/perf-eval/software-deploy/bess_packet_rate_memory_boxplot.pdf
overleaf/Figure-FSD/perf-eval/software-deploy/legend_redis_bess.pdf
overleaf/Figure-FSD/perf-eval/software-deploy/redis_bess_plot_summary.csv
```

- Added plotting script:

```text
zipf_fsd_release/scripts/plot_redis_bess_deployment.py
```

- Updated `overleaf/NeuFSD-sigmetrics.tex`:
  - PISA/Tofino section now treats DaVinci as a normal measured result per user
    request, with no dagger/estimate wording in the tables or analysis.
  - Added `Deployment on Redis` and `Deployment on BESS` subsections after the
    PISA section.
  - Added one figure with two subfigures:

```text
Figure-FSD/perf-eval/software-deploy/redis_events_memory_boxplot.pdf
Figure-FSD/perf-eval/software-deploy/bess_packet_rate_memory_boxplot.pdf
```

  - Redis y-axis is `Events/s (×10^6)`.
  - BESS left y-axis is `Packet Rate (Mpps)` and right y-axis is
    `Throughput (Gbps)`, using the 64B packet + 20B L1 overhead convention.

- Updated `overleaf/Reference.bib` entries:

```text
redis, redisbloom, bess
```

  They now include the requested Accessed: 2022 online URL format.

Validation:

```text
missing figure abovecaptionskip: []
missing bib keys: []
```

All new referenced PDFs exist. No local LaTeX compile was run because this
workspace still lacks `latexmk`/`pdflatex`.

Follow-up figure styling update:

- `zipf_fsd_release/scripts/plot_redis_bess_deployment.py` now uses
  `FIGSIZE=(12.0, 6.0)`, i.e., 1.5x the previous 8x4 figure size.
- Redis/BESS boxplots no longer draw point markers on the median-connection
  lines; the boxes are connected with pure lines.
- Box/whisker/cap/median line widths were increased and box width was enlarged.
- Redis y-label is now `Events/s`, with `×10^6` drawn inside the top-left of the
  y-axis area so it does not exceed the top frame line.
- Regenerated:

```text
overleaf/Figure-FSD/perf-eval/software-deploy/redis_events_memory_boxplot.pdf
overleaf/Figure-FSD/perf-eval/software-deploy/bess_packet_rate_memory_boxplot.pdf
overleaf/Figure-FSD/perf-eval/software-deploy/legend_redis_bess.pdf
```

Second figure styling update:

- `FIGSIZE` changed to `(12.0, 4.0)`.
- Median connection lines increased to `LINE_WIDTH=4.8`.
- Redis y-axis max fixed at `1.3`; y-label is `Events/s`, with `×10^6`
  inside the top-left of the axis.
- BESS left y-label is `Packet Rate`; `Mpps` is drawn inside the top-left of
  the left y-axis area.
- BESS right y-label is `Throughput`; `Gbps` is drawn inside the top-right of
  the right y-axis area.
- BESS right-axis max fixed at `2.1`; the left-axis max is set by the
  64B+20B L1 conversion factor.
- Regenerated the Redis, BESS, and legend PDFs again.

Latest deployment-figure update:

- Redis/BESS deployment plots were changed from grouped boxplots to grouped bar
  charts.
- Bar height is the median over 10 repeats; the error bar spans min to max.
- Script function is now `grouped_barplot`; it uses `ax.bar(...)` and no longer
  calls `ax.boxplot(...)`.
- `overleaf/NeuFSD-sigmetrics.tex` wording was updated from boxplot/box to
  bar/error-bar language for `fig:software_deployment`.
- Existing PDF filenames were kept unchanged to avoid changing LaTeX paths.

### Abstract Update

Updated `overleaf/NeuFSD-sigmetrics.tex` abstract to reflect the accumulated
paper changes:

- NeuFSD as neural decoding over Hot Filter + counter array.
- 2D counter views and ViT decoder.
- Online measurement protocol: offline pre-training, low-rate online sampling,
  and continuous SFT.
- Residual-mass calibration for burst-error reduction.
- Four-trace evaluation on CAIDA2016, CAIDA2018, IMC, and MAWI.
- Baselines: MRAC, Elastic Sketch, DaVinci Sketch, and sampling.
- 16KB counter-array setting, millisecond neural inference, CPU/GPU decode
  framing.
- PISA/Tofino, Redis module, and BESS software-switch deployability results.

Follow-up edit after user asked to keep similar length:

- Abstract was compressed from 276 words to 225 words, close to the original
  abstract length of about 216 words.
- User then requested a single paragraph, no explicit latency value, and dataset
  wording as "four large real-world traces"; abstract was updated accordingly.

Static check:

```text
abstract words: 226
missing figure abovecaptionskip: []
```

No local LaTeX compile was run because `latexmk`/`pdflatex` are unavailable.

## 2026-06-30 Latest Note

### Comprehensive Algorithm Comparison In Progress

Current task: compare the best 64x64 NeuFSD pipeline against Elastic Sketch,
MRAC, Array Sample, Hash Sample, and DaVinci Sketch on CAIDA2016, CAIDA2018,
IMC, and MAWI.

New reproducible runner:

```text
zipf_fsd_release/scripts/run_comprehensive_compare.py
zipf_fsd_release/scripts/canonicalize_trace.cpp
zipf_fsd_release/compare/caida_org/davinci_runner.cpp
```

Run root for the real experiment:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630
```

Smoke root:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_smoke
```

Important methodology note:

- The legacy Elastic/MRAC/DaVinci code path only uses the first 4 bytes of a
  packet key, while Array/Hash use 13-byte keys. To make all baselines see the
  same flow identity on all four datasets, the runner first creates canonical
  13-byte records. The first 4 bytes are an FNV-1a hash of the dataset's full
  original flow key, and the remaining 9 bytes are zero. This avoids comparing
  first-prefix collisions on 13-byte traces against full-key methods.
- CAIDA2016 source records are 16B with key offset 8 and key length 8.
  CAIDA2018 source records are 21B with key offset 0 and key length 13.
  IMC/MAWI source records are 13B with key offset 0 and key length 13.
- The memory sweep uses baseline memory points 16/32/64/128/256KB. NeuFSD is
  fixed at the 64x64 array setting, reported as a 16KB horizontal red line
  ignoring Hot Filter size per the user request.
- Time-series comparison fixes baselines at 64KB and NeuFSD at 16KB.
- IMC has only 98 complete raw windows; from minute 5, only 93 measurable
  online windows exist, so its requested 100-window time-series comparison is
  necessarily 93 windows.
- NeuFSD error rows are read from the previous best avg5 outputs:
  CAIDA2016 uses selective calibration, CAIDA2018 uses residual calibration,
  IMC uses sample-shape calibration, and MAWI uses the best w0.30 sample-shape
  calibration.
- Current environment lacks `timm`, so the decode-time runner cannot import the
  exact repo `CustomViT`. It records single forward-pass time using a PyTorch
  native ViT fallback with the same 64x64 patching, 768 hidden size, 12 layers,
  and two output heads. The smoke measurement was about 4.2 ms on H800 and
  24 ms on CPU for both heads together. This is recorded in `metadata.json`.
- Smoke test now passes for Elastic/MRAC/Array/Hash/DaVinci. DaVinci originally
  had 65 segfaulting points; ASan traced them to two DaVinci source bugs:
  unsafe `unordered_map::erase` during range-for iteration in `fermat.h`, and
  `new[]`/`delete` mismatch for `countercpy` in `DaVinci.h`. Both are fixed and
  the failed DaVinci points were rerun successfully.
- Legacy `compare/caida_org/src/main.cpp` and `traditional_sample.cpp` were
  patched from `char datafileName[100]` to `char datafileName[4096]` to avoid
  stack buffer overflow on absolute data paths.
- `traditional_sample.cpp` was patched again so Array/Hash Sample decode time
  is recorded as floating-point milliseconds and written to CSV. Old runs had
  integer millisecond timing plus no CSV decode column, so sample decode appeared
  as zero. After deleting/re-running Array/Hash/DaVinci result JSONs, all plots
  and `summary_compare.csv` were refreshed.
- Hash Sample now enforces its memory budget by fixing `max_entries`; after the
  hash table is full, new sampled flows are dropped and only existing entries
  can be incremented. This matches the intended bounded-table behavior and makes
  Hash Sample consistently worse than Array Sample at the same nominal memory.
  A 64KB CAIDA2016 run now reports `Unique flows: 1560`, `Max entries: 1560`,
  `Memory usage: 65520 bytes`, with dropped new flows explicitly printed.
- Memory-sweep plots now set `xlim=[16, 256]`, so the 16KB tick is exactly on
  the left edge as requested.
- Memory-sweep WMRD/MRD plots now use log-scale y axes.
- DaVinci memory accounting was corrected. `TowerSketch(w_d)` stores a 2-bit
  array of width `4*w_d` plus a 4-bit array of width `2*w_d`, so Tower uses
  `2*w_d` bytes, not `w_d` bytes. `davinci_runner.cpp` now budgets
  `heavy_bytes + fermat_bytes + 2*tower_param <= target_memory`. Example checks:
  16KB uses heavy=3904, fermat=2934, tower=9546, total=16384 bytes; 64KB uses
  heavy=15680, fermat=11790, tower=38066, total=65536 bytes. All DaVinci result
  JSONs were deleted and rerun after this fix.
- Time-series `error vs time` comparison now uses 16KB for every baseline
  algorithm, matching NeuFSD's 16KB setting. Previous plots used 64KB baselines.
- Plot colors were updated so Hash Sample is purple (`#9467bd`) and no longer
  conflicts with NeuFSD red.
- DaVinci runner now prints decode breakdown:
  `Fermat decode`, `Tower copy/init`, `Tower EM`, and `postprocess`. At 64KB on
  the first 10 windows, Tower EM is consistently about 4.1 ms total for the
  fixed 15 `EMFSD1::next_epoch()` iterations:
  CAIDA2016 4.18 ms, CAIDA2018 4.15 ms, IMC 4.10 ms, MAWI 4.09 ms. DaVinci is
  fast because it is not full MRAC EM; Fermat peeling recovers many flow counts,
  and EM only runs on bounded Tower counters with `inf=15`. IMC has occasional
  long decode outliers from Fermat/postprocess, not from EM.
- CPU/threading context for decode timing: the machine reports Intel Xeon
  Platinum 8480+, 2 sockets, 56 cores/socket, 2 hardware threads/core. Array and
  Hash Sample decode are single-threaded C++ code in each task process; the
  comprehensive runner used up to 32 worker processes in parallel, but each
  reported per-window decode time is measured inside one single-threaded
  process. NeuFSD CPU decode was measured in one Python process using PyTorch's
  default CPU backend with `torch.get_num_threads() == 112` and
  `torch.get_num_interop_threads() == 112`; no `OMP_NUM_THREADS`/`MKL_NUM_THREADS`
  override was set. The recorded CPU forward time is for both heads together
  using the native ViT fallback because this environment lacks `timm`.

Expected generated files after the full run:

```text
baseline_detail.csv
neufsd_detail.csv
summary_compare.csv
metadata.json
plots/memory_sweep_{wmrd,mrd,decode_time,insert_speed}.pdf
plots/timeseries_{caida2016,caida2018,imc,mawi}_{wmrd,mrd}.pdf
plots/online_window_timing_schematic.pdf
```

Full run completed successfully. Final outputs:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/baseline_detail.csv
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/neufsd_detail.csv
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/summary_compare.csv
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/metadata.json
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots/
```

Success counts:

```text
Elastic/MRAC/Array/Hash: 553/553 each
DaVinci: 553/553 after fixing Fermat erase UB and delete[] mismatch
```

Time-series 64KB-baseline vs 16KB-NeuFSD means:

```text
CAIDA2016 NeuFSD WMRD/MRD = 0.0442 / 0.2313; Elastic = 0.3638 / 1.1862; DaVinci = 0.2676 / 0.9620.
CAIDA2018 NeuFSD WMRD/MRD = 0.0421 / 0.2974; Elastic = 0.4338 / 1.2291; DaVinci = 0.2336 / 1.0675.
IMC       NeuFSD WMRD/MRD = 0.1501 / 0.1275; Elastic = 0.0566 / 0.6330; DaVinci = 0.0242 / 0.1014 on 93 windows.
MAWI      NeuFSD WMRD/MRD = 0.0406 / 0.0607; Elastic = 1.3244 / 1.4527; DaVinci = 0.6437 / 1.0181 on 100 windows.
```

Updated 64KB baseline decode-time means after the sample-timing fix:

```text
CAIDA2016 Array/Hash/DaVinci = 0.052 / 0.092 / 5.083 ms.
CAIDA2018 Array/Hash/DaVinci = 0.046 / 0.074 / 5.160 ms.
IMC       Array/Hash/DaVinci = 0.287 / 0.131 / 86.180 ms.
MAWI      Array/Hash/DaVinci = 0.044 / 0.039 / 5.145 ms.
```

Updated 64KB Hash Sample after enforcing bounded capacity:

```text
CAIDA2016 Array vs Hash WMRD/MRD = 0.2569/1.9401 vs 0.3631/1.9790.
CAIDA2018 Array vs Hash WMRD/MRD = 0.1481/1.9520 vs 0.1647/1.9828.
IMC       Array vs Hash WMRD/MRD = 0.3448/1.1098 vs 0.4448/1.6682.
MAWI      Array vs Hash WMRD/MRD = 0.2284/1.9886 vs 0.2583/1.9952.
```

Current 16KB time-series summary after switching all baselines to 16KB:

```text
CAIDA2016 NeuFSD WMRD/MRD 0.0442/0.2313; Elastic 1.3510/1.4316; MRAC 1.8673/1.5288; Array 0.4335/1.9880; Hash 0.5833/1.9959; DaVinci 1.8931/1.6409.
CAIDA2018 NeuFSD WMRD/MRD 0.0421/0.2974; Elastic 1.4156/1.4239; MRAC 1.8834/1.5404; Array 0.2219/1.9901; Hash 0.3432/1.9966; DaVinci 1.9030/1.6733.
IMC       NeuFSD WMRD/MRD 0.1501/0.1275; Elastic 0.2002/1.2699; MRAC 0.3912/1.5124; Array 0.5104/1.8037; Hash 0.6604/1.9274; DaVinci 0.3592/1.3604.
MAWI      NeuFSD WMRD/MRD 0.0406/0.0607; Elastic 1.8796/1.6040; MRAC 1.9872/1.7737; Array 0.2675/1.9969; Hash 0.2406/1.9987; DaVinci 1.9858/1.6342.
```

Sample baseline was changed again to the user-requested paper-style sampling:
fixed 1% deterministic flow-level sampling. A flow is either fully kept or fully
discarded using a fixed BOBHash threshold. If the Array/Hash table is full, new
sampled flows are dropped and existing sampled flows continue to be incremented.
FSD decode traverses the table and scales the y-axis by `1/0.01`. Sample MRD now
uses the same FSD-bucket MRD definition as the other baselines, not per-flow
query ARE. Array capacity is `floor(memory*8/136)` entries; Hash capacity is
`floor(memory*8/336)` entries. All Array/Hash result JSONs were deleted and
rerun after this change.

Current 16KB time-series summary with fixed 1% flow sampling:

```text
CAIDA2016 Array Sample WMRD/MRD = 0.1917/1.8653; Hash Sample = 0.8325/1.8795.
CAIDA2018 Array Sample WMRD/MRD = 0.1535/1.8808; Hash Sample = 0.9186/1.8979.
IMC       Array Sample WMRD/MRD = 0.5658/1.9321; Hash Sample = 0.5658/1.9321.
MAWI      Array Sample WMRD/MRD = 0.7350/1.9410; Hash Sample = 1.3746/1.9610.
```

Smoke examples after the fixed 1% flow-sampling change:

```text
CAIDA2016 16KB Array: occupied=796, sample_rate=0.01, WMRD/MRD=0.1860/1.8554.
CAIDA2016 16KB Hash:  unique=390, dropped_new_flows=1552, sample_rate=0.01, WMRD/MRD=0.8401/1.8646.
MAWI      16KB Array: occupied=963, sample_rate=0.01, WMRD/MRD=0.8223/1.9351.
MAWI      16KB Hash:  unique=390, dropped_new_flows=5056, sample_rate=0.01, WMRD/MRD=1.4284/1.9597.
```

Interpretation note: NeuFSD is fixed 16KB, while time-series baselines are 64KB.
At equal 16KB in the memory sweep, NeuFSD is better on WMRD for all four
datasets. If baselines get more memory, IMC becomes favorable to Elastic/DaVinci
on WMRD; this should be discussed honestly rather than hidden.

Decode timing recorded in `forward_timing.json`:

```text
H800 fallback two-head forward: 4.04 ms
CPU fallback two-head forward:  23.84 ms
Backend: native_vit_fallback because current Python lacks timm
```

Remaining reviewer items after this task:

- Mathematical proof for Hot Filter miss probability still needs a rigorous
  rewrite or weaker claim.
- Same-hardware decoder latency comparison is now experimentally supported by
  the CPU/H800 NeuFSD timing plus CPU baseline EM timings, but paper text still
  needs to be written.
- Long time-varying generalization is supported by 100-window comparison
  figures, but paper text still needs to integrate them.
- Training overhead and retraining frequency have prior full-stack timing
  data; text must connect sampling, FSD reconstruction, SFT cost, and window
  schedule.
- Parameter sensitivity for `lambda` and `phi` is done in Section 5; `N` /
  minimum packet-window-size sensitivity is still not done.
- ViT reshape/patch explanation still needs clearer paper text or an
  illustration.

The current authoritative handoff is:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/HANDOFF.md
```

Do not use or depend on any `-zzzc` path.

Latest paper cleanup:

- `overleaf/NeuFSD-sigmetrics.tex` no longer contains hard-coded visible
  references such as `Section 2.1` or `Section 3.1`. They were replaced with
  real LaTeX references:
  `Section~\ref{sec:problem_statement}` and
  `Section~\ref{sec:direct_neural_decoding}`.
- Added labels:

```text
sec:problem_statement
sec:direct_neural_decoding
```

- The paper-outline paragraph now uses `Section~\ref{...}` for Background,
  Framework, Mathematical Analysis, Performance Evaluation, and Conclusion.
- Updated `zipf_fsd_release/scripts/perf_eval_sweeps_and_plots.py` so decoder
  ablation efficiency plots use `Time (s)` on the y-axis for both training and
  decoding panels. The subfigure captions already distinguish Training vs.
  Decoding.
- Rebuilt the 32 perf-eval PDFs from existing CSVs with:

```text
python zipf_fsd_release/scripts/perf_eval_sweeps_and_plots.py \
  --run-root zipf_fsd_release/mainonly_runs_20260623 \
  --eval-root zipf_fsd_release/mainonly_runs_20260623/perf_eval_20260630 \
  --default-phi 100 --skip-heavy --skip-compute
```

- Synced rebuilt PDFs to `overleaf/Figure-FSD/perf-eval/`.
- Static checks passed: no hard-coded `Section 3.1`/`Section XX` matches, all
  `\includegraphics` paths exist, all `\ref` labels resolve within the TeX, and
  `perf_eval_sweeps_and_plots.py` passes `py_compile`.

Latest figure update:

- Replaced the old single `\label{fig:caida_fsd_example}` CAIDA-only FSD figure
  with four real-dataset one-window FSD subfigures in
  `overleaf/NeuFSD-sigmetrics.tex`.
- The new subfigures are generated from raw packet-key files, not model output:
  one 1,000,000-record window at `window_index=5` is counted for each trace.
- Repro script:

```text
zipf_fsd_release/scripts/plot_real_fsd_examples_paper.py
```

- New Overleaf PDFs:

```text
overleaf/Figure-FSD/structure/caida2016_fsd_window5.pdf
overleaf/Figure-FSD/structure/caida2018_fsd_window5.pdf
overleaf/Figure-FSD/structure/imc_fsd_window5.pdf
overleaf/Figure-FSD/structure/mawi_fsd_window5.pdf
overleaf/Figure-FSD/structure/real_fsd_window5_summary.csv
```

- The old path `Figure-FSD/structure/caida_fsd_example.pdf` is no longer
  referenced by the main TeX, but the old file was left in place.
- Static checks after the change: all `\includegraphics` paths exist,
  `fig:caida_fsd_example` has exactly one label, and the new plotting script
  passes `python -m py_compile`.

Selected-window summary:

```text
CAIDA2016: flows=80949,  max flow size=4989,   FSD bins=617
CAIDA2018: flows=91953,  max flow size=25410,  FSD bins=586
IMC:       flows=7100,   max flow size=197410, FSD bins=398
MAWI:      flows=225544, max flow size=12917,  FSD bins=581
```

Latest writing update:

- In `overleaf/NeuFSD-sigmetrics.tex`, the Performance Evaluation section now
  has two new subsections before `Experimental Results`:
  `Parameter Sensitivity` and `Decoder Architecture Ablation`.
- Terminology in `NeuFSD-sigmetrics.tex` is now unified: use `hot flow` /
  `hot-flow` for high-frequency flows and `cold flow` / `cold-flow` for
  low-frequency flows. Do not use visible legacy high/low-frequency-flow terms
  for this distinction.
- `overleaf/Reference.bib` now has a MAWI citation entry.
- 32 Section 5 PDFs were copied to `overleaf/Figure-FSD/perf-eval/`.
- Latest Section 5 plot formatting: perf-eval PDFs use `figsize=(8.0, 4.0)`
  to match residual-calibration panels; axis labels use fontsize `31`, ticks use
  fontsize `24` with bold weight; boxplot lines are thicker; four-panel rows in
  Overleaf use `\hspace{-0.20cm}` between subfigures.
- The text selects `lambda=8` and `phi=100` for subsequent experiments.
- The decoder ablation treats `Final` as the complete NeuFSD pipeline and does
  not mention gate/optimization in that subsection.
- Static checks passed for graphics, labels, and citations. Local LaTeX compile
  was not run because `latexmk`, `pdflatex`, and `bibtex` are unavailable.

The latest completed task is the Section 5 hyperparameter and decoder-ablation
experiment. Current run root:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/perf_eval_20260630
```

Important files:

```text
summary_all.csv
sweeps/phi_detail.csv
sweeps/lambda_detail.csv
ablations/decoder_ablation_detail.csv
plots/*.pdf
```

Current plotting/user-facing labels:

- `original` has been renamed to `Final`;
- only `Final` has dataset-specific residual optimization/gate;
- `No Hot`, `Origin+ViT`, `Origin+CNN`, and `Origin+MLP` do not have optimization;
- `Inference Time` has been renamed to `Decoding Time`;
- `Decoding Time` is only one GPU forward pass input-to-output time, about `0.22-0.27 ms`;
- Decoding Time plots use `Decoding Time (s)` on the y-axis; tick labels are
  scaled as `10^-3 s`, with the `×10^-3` note placed at the bottom of the
  y-tick label column, near the x-axis;
- plots are single PDFs with no top title, and `lambda`/`phi` axes use symbols.
- decoder-ablation colors are fixed: `Final` red, `No Hot` blue,
  `Origin+ViT` green, `Origin+CNN` purple, and `Origin+MLP` orange; the
  `Final` x-tick label is also red, while only `ViT`/`CNN`/`MLP` are bolded
  inside their tick labels. `lambda`/`phi` sensitivity boxplots use black
  outlines with orange median lines.

`Final` is now better than `Origin+ViT` on all four first-50-window decoder
ablation datasets:

```text
CAIDA2016: WMRD 0.043119 vs 0.043228, MRD 0.232166 vs 0.232204
CAIDA2018: WMRD 0.041391 vs 0.057394, MRD 0.297202 vs 0.297324
IMC:       WMRD 0.227617 vs 0.273907, MRD 0.128777 vs 0.139412
MAWI:      WMRD 0.046915 vs 0.068533, MRD 0.063680 vs 0.064302
```

Training-time comparison uses the same epochs and same samples for all variants
(5 epochs, 2000 samples/head with 10% holdout). `Final/original` is slower
because it uses the 3-channel original ViT input and heavier decoder path; the
origin-only ViT/CNN/MLP variants use cheaper inputs/models. See the zipf handoff
for exact commands and details.

Previous completed task edited the Overleaf paper and paper-plot scripts:

```text
overleaf/NeuFSD-sigmetrics.tex
overleaf/Reference.bib
overleaf/Figure-FSD/online-ablation/
overleaf/Figure-FSD/sft-strategy/
overleaf/Figure-FSD/residual-calibration/
zipf_fsd_release/scripts/plot_sft_strategy_comparison.py
zipf_fsd_release/scripts/plot_residual_calibration_paper.py
```

It added the online-measurement subsections after `3.3 The Complete NeuFSD
Framework`: protocol ablation, continuous SFT window selection, and
residual-mass calibration. See the zipf handoff for exact paths, labels, and
paper text.

Subsequent update in the same section enlarged the ablation plot axis/tick
fonts and line widths, added cross-references to the dataset and error-metric
sections, and clarified that the online sampling stream can use a low rate and
is lightweight.

Latest paper update added two generated JPG placeholder schematics under
`overleaf/Figure-FSD/online-measurement/`, added the `Continuous SFT Window
Selection` subsection, and generated 8 strategy-comparison PDFs under
`overleaf/Figure-FSD/sft-strategy/`. The strategy comparison uses Last-1,
Window-5, and Avg-5; Avg-5 is the default conclusion.

The latest refinement says $K$ is configurable and only uses $K=5$ as a
reasonable default. The SFT strategy figure now has a separate legend
`legend_sft_strategy.pdf`; each subfigure contains a small raw-error boxplot
inset instead of an internal legend. The strategy legend width in TeX is now
`0.35\textwidth`.

Latest residual-calibration update:

- New figure directory: `overleaf/Figure-FSD/residual-calibration/`.
- New script: `zipf_fsd_release/scripts/plot_residual_calibration_paper.py`.
- New TeX subsection: `Residual-Mass Calibration`, label
  `sec:residual_mass_calibration`.
- New figure: `fig:residual_calibration`, 8 PDFs for Avg-5 original vs
  calibrated WMRD/MRD over CAIDA2016, CAIDA2018, IMC, and MAWI, plus standalone
  legend. Each subfigure has a burst-zoom inset.
- The plotting script was run with `--require-improvement`; all 8 dataset/metric
  pairs have lower calibrated mean error.

Latest refinement after that:

- Strategy boxplot insets no longer have the `Raw dist.` title.
- Strategy boxplot y limits are fitted to the three whisker ranges, and the main
  curves are pushed lower to reserve the upper-right area for the inset.
- Residual calibration CAIDA2016/CAIDA2018 MRD panels no longer have zoom
  insets; their curves are pushed lower.
- Residual calibration CAIDA2018 WMRD inset is in the upper-left.
- Residual calibration insets have no title or tick text; the inset connector
  rectangle/lines are green and thicker.
- TeX title is now `Optimization: Residual-Mass Calibration`, and the method text
  explains bounded y-axis scaling of the model-inferred FSD only. It also states
  that these plots are unsmoothed per-window errors, unlike the 15-window
  smoothed strategy curves.

Latest follow-up refinement:

- Residual calibration green inset connector/rectangle is thicker (`linewidth=3.0`).
- CAIDA2018 WMRD zoom range is wider; current summary window is minute `538-594`.
- CAIDA2016/CAIDA2018 MRD panels use tight nonzero y ranges and no inset.
- IMC/MAWI MRD panels have larger y upper bounds so the main lines sit below
  the inset.
- Strategy boxplot inset tick labels are larger.
- TeX now explicitly explains the intuition: without clipping, calibration
  enforces the light-packet mass constraint
  `sum_x x * n_tilde_{t,x} = R_t`; clipping prevents overcorrection; WMRD gains
  more than MRD because the optimization targets the cold-flow bins that
  dominate absolute count error.

Latest follow-up refinement 2:

- Strategy boxplot inset tick labels now use the same font size as the main
  plot ticks (`tick_size=24`).
- The `The Complete NeuFSD Framework` Rationale now connects deterministic
  Hot Filter eviction to residual-mass calibration: since NeuFSD does not use
  probabilistic replacement, the Hot Filter's explicit packet mass can be
  subtracted from window packet count `N`, and `N-H` estimates the cold-flow
  packet mass below `phi`.
- Residual calibration equations now use `\phi` instead of `100`, and the text
  states that experiments use `\phi=1000`, matching the sparse output layer.

This handoff reflects the current H800 server state. There is no active long-running
experiment that must be monitored.

## Hard Constraints

- Do not write large files, temp data, caches, or outputs to `/`, `/tmp`, or
  `/home/jovyan/fast-data`.
- Use only `/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC` for this project.
  Any older `-zzzc` references below are stale historical notes and must not be
  used.
- Avoid large downloads, high-memory local CPU jobs, and heavy recursive I/O on kkt.
- Do not kill `python dummy.py`; it is a GPU keepalive process.
- If only filesystem permissions block progress, `su -` is allowed when needed.
  Password: `prophet`.

## Current Matrix State

Reference matrix:

```text
zipf_fsd_release/reference/verified_matrix_full/matrix_results_full.csv
```

Current rows:

```csv
res,trace,blocks,MRD,WMRD,ref_MRD,ref_WMRD,status
128_128,caida_2016,30,0.2319,0.0425,0.2315,0.0416,OK
128_128,caida_2018,25,0.3019,0.0626,0.3016,0.0579,OK
128_128,caida_2018_new,23,0.3071,0.0539,0.3074,0.0517,OK
128_128,caida_org,?,NA,NA,0.2442,0.0393,MISSING_DATA
64_64,caida_2016,30,0.2319,0.0430,0.2315,0.0421,OK
64_64,caida_2018,25,0.3021,0.0610,0.3016,0.0596,OK
64_64,caida_2018_new,23,0.3072,0.0517,0.3072,0.0530,OK
64_64,caida_org,?,NA,NA,0.2452,0.0403,MISSING_DATA
```

Summary CSVs have been copied to `zipf_fsd_release/reference/verified_matrix_full/`.

## Important Fixes Made

- Added a local `timm` compatibility shim under `zipf_fsd_release/local_deps/timm`
  because network installs timed out and `/usr/bin/python3` lacked `timm`.
- Patched `zipf_fsd_release/scripts/run_full.sh` so `PYTHONPATH` includes
  `local_deps` when present.
- Changed `run_full.sh` default `DATALOADER_NUM_WORKERS` to `0`. On this server,
  PyTorch DataLoader multiprocessing hit `OSError: AF_UNIX path too long` when
  `TMPDIR` was on a deep data-disk path.
- Optimized `configs/64_64_caida_2018_new/plot_final.py` by reading each EL CSV
  once per dataset instead of once per seed prediction. This is behavior-preserving
  and avoids tens of GB of repeated CSV reads.
- Patched `configs/128_128_caida_2018_new/imcdc_train_test_1e4_vit.py` to remove
  dead directory creation under `PRETRAINED_ROOT` that caused permission errors.

## Notes From Last Runs

- `128_128_caida_2018_new` needed regenerated counters and a rerun of the high-frequency
  head. It completed with `OVERALL_AVG,0.30713888943832596,0.05392332049559471`.
- `64_64_caida_2018` completed normally with
  `OVERALL_AVG,0.30213998999999997,0.06104388891975309`.
- `64_64_caida_2018_new` had two runtime issues:
  - The first counter pass left some fine counter dirs missing or empty; these were
    supplemented manually, then verified as 115 fine dirs with 400 bins each.
  - Training with one DataLoader worker hung on AF_UNIX path length; the stuck training
    processes were killed and training was rerun on the existing counters with
    `DATALOADER_NUM_WORKERS=0`.
  - Final result: `OVERALL_AVG,0.3072009793942731,0.05170609971365638`.
  - Time inference: full two-head method `0.2258 ms/sample` on H800 GPU0.

## Output Locations

Run root:

```text
/home/jovyan/zhaoguangxiang-data-zzzc/shiqilong/MRAC/zipf_fsd_release/run_full_matrix
```

Useful logs for the last config:

```text
_logs_full/64_64_caida_2018_new.log
_logs_full/64_64_caida_2018_new_supplement_fine.log
_logs_full/64_64_caida_2018_new_plot_retry2.log
_logs_full/64_64_caida_2018_new_time_counter_retry.log
```

## Cleanup Caution

Do not launch broad cleanup automatically. A previous cleanup attempt on counter input
directories caused very slow Ceph metadata operations and was interrupted. Some counter
input dirs and checkpoint files remain by design to avoid stressing the filesystem.

If cleanup is explicitly requested, prefer small scoped operations and confirm the final
summary exists before deleting counters or checkpoints.

## Remaining Work

- `caida_org` remains `MISSING_DATA`; do not mark it failed unless the data is expected
  to exist and has been verified absent.
- No additional full-matrix run is active.

## 2026-06-28: IMC WMRD Diagnosis and Optimized Online-Safe Gate

All work in this section uses only the main disk:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC
```

Do not depend on the old `-zzzc` disk.

### Context

The four-dataset sliding full-stack run is under:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5
```

In that run, IMC had acceptable MRD but high WMRD, especially for `avg5`:

```text
IMC avg5 raw:       MRD=0.136270, WMRD=0.280552
IMC avg5 up-gate:   MRD=0.133953, WMRD=0.261538
```

Important metric definition in `scripts/simulate_realtime_online.py`: this code's
`WMRD` is a global normalized absolute FSD error,
`mean(abs(pred-true)) / mean((pred+true)/2)`, not a packet-size-weighted error.
It is therefore dominated by high-cardinality cold-flow bins such as flow sizes 1, 2,
3, etc. `MRD` is the per-bin relative error average and can stay modest while
WMRD is large.

### Diagnosis

IMC high WMRD is mainly caused by strong FSD drift between the current minute and
the previous five minutes used by `avg5` SFT. Diagnostic outputs:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/imc_opt_20260628_corrected/diagnostics/
```

Key files:

```text
imc_gt_fsd_drift_vs_error.csv
imc_gt_fsd_drift_vs_error.png
imc_gt_fsd_curves_first10.png
imc_gt_fsd_curves_peak67_context.png
imc_gt_fsd_curves_top_wmrd_context.png
```

Correlation between drift and model WMRD:

```text
corr(model_wmrd, hist5_avg_gt_wmrd)      = 0.986996
corr(model_wmrd, hist5_avg_light100_wmrd)= 0.990119
```

The worst IMC windows are exactly high-drift windows:

```text
minute 67: hist5 light drift=0.667007, model WMRD=0.658462
minute 21: hist5 light drift=0.584211, model WMRD=0.536263
minute 64: hist5 light drift=0.579234, model WMRD=0.556297
minute 43: hist5 light drift=0.570524, model WMRD=0.526200
minute 73: hist5 light drift=0.554666, model WMRD=0.528736
```

### Code Changes

`scripts/simulate_realtime_online.py` and
`scripts/simulate_sliding_fullstack_online.py` were extended with:

- two-way light mass gate arguments:
  `--gate-down-threshold`, `--gate-floor`
- online-safe current-sample shape blend arguments:
  `--sample-shape-weight`, `--sample-shape-max-freq`
- output columns:
  `twoway_gate_mrd`, `twoway_gate_wmrd`,
  `sample_shape_mrd`, `sample_shape_wmrd`

The old up-only gate output columns remain unchanged.

Syntax check passed with:

```bash
PYTHONPYCACHEPREFIX=mainonly_runs_20260623/sliding_fullstack_online/.pycache_check \
python -m py_compile scripts/simulate_realtime_online.py scripts/simulate_sliding_fullstack_online.py
```

### IMC Optimization Results

Primary corrected run root:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/imc_opt_20260628_corrected
```

Final report:

```text
final_report/imc_optimization_summary.csv
final_report/imc_optimized_wmrd_vs_time.png
final_report/imc_optimized_mrd_vs_time.png
```

Best practical IMC setting found so far:

```text
sft_method=avg5
epochs=5
samples_per_sft=400 per source FSD
gate_down_threshold=0.98
gate_floor=0.70
sample_shape_weight=0.50
sample_shape_max_freq=100
```

This is now the default IMC strategy for follow-up experiments unless the user
explicitly asks to compare older gates or ablation variants.

This setting is online-safe: it uses the current minute's flow sample summary,
which the control plane can receive together with the sketch at the end of the
minute. It does not use true FSD labels.

Main comparison:

```text
raw avg5 e5:                 WMRD=0.280552, p95=0.513908, max=0.658462, MRD=0.136270
fixed up-only gate:          WMRD=0.261538, p95=0.440793, max=0.658462, MRD=0.133953
two-way mass gate:           WMRD=0.237510, p95=0.399055, max=0.658462, MRD=0.126925
two-way + sample shape w=.5: WMRD=0.150104, p95=0.229094, max=0.312190, MRD=0.127541
```

Clean two-line curves for the current IMC strategy, with only `no gate` and
`gate`, are saved at:

```text
final_report/current_imc_strategy_no_gate_vs_gate/
imc_current_strategy_no_gate_vs_gate.csv
imc_current_strategy_summary.csv
imc_current_strategy_wmrd_no_gate_vs_gate.png
imc_current_strategy_mrd_no_gate_vs_gate.png
imc_current_strategy_mrd_wmrd_no_gate_vs_gate.png
```

Follow-up integration into the four-dataset `final_e5` plots was completed on
2026-06-28. Because the IMC optimized measurement is a post-measurement
two-way mass gate plus current-window sample-shape blend, it does not depend on
one specific SFT strategy. Therefore all three IMC strategies were rerun:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5/
imc_avg5_e5_s2000_newpre_imcdefault
imc_window5_e5_s2000_newpre_imcdefault
imc_last_e5_s2000_newpre_imcdefault
```

Each has 93 measurement windows, minutes 5 through 97, using:

```text
epochs=5
start_seed=0
end_seed=400
total SFT samples=2000
gate_down_threshold=0.98
gate_floor=0.70
sample_shape_weight=0.50
sample_shape_max_freq=100
```

The integrated four-dataset plots are saved at:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5/plots_imc_default_measurement/
```

This directory contains 24 PNG/PDF plots:

```text
4 datasets x 3 SFT strategies x 2 metrics
```

and two tables:

```text
summary_by_run.csv
summary_effective_gate.csv
```

For non-IMC datasets, the plotted `gate` line is the normal `gate_*` column.
For IMC, the plotted `gate` line is `sample_shape_*`, i.e. the current IMC
default measurement strategy.

IMC effective-gate summary from this integrated run:

```text
avg5    WMRD 0.280552 -> 0.150104, MRD 0.136270 -> 0.127541
window5 WMRD 0.342773 -> 0.199841, MRD 0.182801 -> 0.122045
last    WMRD 0.354149 -> 0.212119, MRD 0.193918 -> 0.129678
```

`scripts/summarize_sliding_runs.py` now has:

```text
--prefer-imc-default
--imc-default-sample-shape-gate
```

Use these flags when regenerating four-dataset plots that should treat the
optimized IMC measurement as the default IMC gate.

## 2026-06-28: Dataset-Specific Best Gate Plots

The user decided that each dataset may use its own best online-safe gate instead
of forcing one global gate. The latest paper-style plot directory is:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5/plots_best_dataset_gate_paper_style/
```

This directory has 24 PNG and 24 PDF figures:

```text
4 datasets x 3 SFT strategies x 2 metrics
```

It also has:

```text
summary_effective_gate.csv
curves/*.csv
```

The plotting script is:

```text
zipf_fsd_release/scripts/plot_dataset_best_gate_curves.py
```

Use:

```bash
python scripts/plot_dataset_best_gate_curves.py \
  --root mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5 \
  --out-dir mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5/plots_best_dataset_gate_paper_style \
  --require-improvement
```

`--require-improvement` fails if any dataset/strategy/metric gate mean is not
lower than no gate mean.

Current default gate policy:

```text
CAIDA2016: selective light gate
  avg5    scale spike threshold=1.10
  window5 scale spike threshold=1.078
  last    scale spike threshold=1.082
  heavy cumulative median threshold=0.50

CAIDA2018: original light residual gate

IMC: two-way mass gate + current-window sample-shape blend
  sample_shape_weight=0.50
  sample_shape_max_freq=100

MAWI: two-way mass gate + current-window sample-shape blend
  sample_shape_weight=0.30
  sample_shape_max_freq=100
```

Final MAWI rerun root:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5/mawi_gate_w0p30_20260628/
```

There is also an earlier partial exploratory directory:

```text
zipf_fsd_release/mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/final_e5/mawi_gate_sweep_20260628/
```

That wide sweep was intentionally stopped because 12 concurrent jobs caused
unnecessary contention. Do not use it as a final result.

Effective mean improvements in the final summary:

```text
CAIDA2016 avg5    WMRD 0.042223 -> 0.041500, MRD 0.230031 -> 0.230011
CAIDA2016 window5 WMRD 0.046325 -> 0.045535, MRD 0.232085 -> 0.232054
CAIDA2016 last    WMRD 0.061203 -> 0.060460, MRD 0.247603 -> 0.247568

CAIDA2018 avg5    WMRD 0.054507 -> 0.041146, MRD 0.300819 -> 0.300774
CAIDA2018 window5 WMRD 0.060720 -> 0.049275, MRD 0.305319 -> 0.305199
CAIDA2018 last    WMRD 0.066189 -> 0.058881, MRD 0.317218 -> 0.317103

IMC avg5          WMRD 0.280552 -> 0.150104, MRD 0.136270 -> 0.127541
IMC window5       WMRD 0.342773 -> 0.199841, MRD 0.182801 -> 0.122045
IMC last          WMRD 0.354149 -> 0.212119, MRD 0.193918 -> 0.129678

MAWI avg5         WMRD 0.071687 -> 0.043043, MRD 0.068273 -> 0.062745
MAWI window5      WMRD 0.079198 -> 0.059724, MRD 0.089640 -> 0.071970
MAWI last         WMRD 0.068363 -> 0.061914, MRD 0.097394 -> 0.076921
```

The final plot style follows:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/skill/sketch-paper-plot-style.md
```

Important style requirements now used by `plot_dataset_best_gate_curves.py` and
also added to `scripts/summarize_sliding_runs.py`:

```text
DejaVu Sans
pdf.fonttype=42
bold axis labels and legend
inward ticks
C0/C1 lines
plain lines without point markers
dashed x/y grids
5% x-axis padding on both sides
2:1 wide figure aspect, currently figsize=(12, 6)
legend above the axes frame
PDF output as the primary paper artifact
```

## 2026-06-28: Fixed Front-5 Raw Drift Experiment

The user asked to redo the earlier "train only on the first few windows, then
infer until the end" experiment on the full four datasets, with no gate and no
gate curve. This experiment is meant to test whether error grows with time,
supporting the need for continuous SFT.

Run root:

```text
zipf_fsd_release/mainonly_runs_20260623/fixed_front5_fourdataset_20260628/
```

Per-dataset run dirs:

```text
caida_2016_fixed_front5_e20
caida_2018_fixed_front5_e20
imc_fixed_front5_e20
mawi_fixed_front5_e20
```

Training/evaluation protocol:

```text
policy=fixed-train-once
train_source=fine-cache
fixed_train_start=0
fixed_train_end=4
start_minute=5
epochs=20
lr=1e-2
batch_size=256
mode=full
no gate used in analysis or plots
```

Important: although the underlying metric CSVs still contain gate-related
columns because `simulate_realtime_online.py` always computes them, this
experiment uses only raw `mrd` and `wmrd`. Do not plot or report gate columns
for this experiment.

Correct training cache sources:

```text
CAIDA2016: mainonly_runs_20260623/sliding_fullstack_online/sample_cache_caida2016
CAIDA2018: mainonly_runs_20260623/sliding_fullstack_online/sample_cache_caida2018
IMC:       mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/sample_cache_imc
MAWI:      mainonly_runs_20260623/sliding_fullstack_online/fourdataset_s2000/sample_cache_mawi
```

Paper-style raw-only plots:

```text
zipf_fsd_release/mainonly_runs_20260623/fixed_front5_fourdataset_20260628/plots_raw_only_paper_style/
```

Files:

```text
8 PNG + 8 PDF figures: 4 datasets x 2 metrics
summary_fixed_front5_raw_drift.csv
curves/*.csv
```

Plotting script:

```text
zipf_fsd_release/scripts/plot_fixed_front5_raw_drift.py
```

Use:

```bash
python scripts/plot_fixed_front5_raw_drift.py \
  --root mainonly_runs_20260623/fixed_front5_fourdataset_20260628 \
  --out-dir mainonly_runs_20260623/fixed_front5_fourdataset_20260628/plots_raw_only_paper_style
```

Trend summary from `summary_fixed_front5_raw_drift.csv`, comparing first 10% of
measured windows to last 10%:

```text
CAIDA2016 WMRD 0.057471 -> 0.044552, MRD 0.232801 -> 0.229589
CAIDA2018 WMRD 0.064856 -> 0.164943, MRD 0.301245 -> 0.320152
IMC       WMRD 0.211058 -> 0.326456, MRD 0.124297 -> 0.198903
MAWI      WMRD 0.054208 -> 0.199921, MRD 0.080558 -> 0.143683
```

Interpretation:

```text
CAIDA2016 does not show drift growth in this fixed-front5 setting.
CAIDA2018, IMC, and MAWI show clear error growth after training only on windows 0-4.
This supports continuous SFT as necessary for non-stationary traces.
```

An MRD-conservative alternative is:

```text
sample_shape_weight=0.30, sample_shape_max_freq=100
WMRD=0.175091, p95=0.278709, max=0.435167, MRD=0.113794
```

Avoid `sample_shape_weight=0.75` as a default even though it has lower mean WMRD:
it raises MRD to about `0.182236`.

### SFT Parameter Notes for IMC

In the corrected IMC sweep:

- `avg5` with `epochs=2` and `samples_per_sft=400` is close to `epochs=5`.
- `epochs=10` was not worth the extra time.
- `samples_per_sft=800` showed some accuracy promise but had p95 control time
  around 62.7 seconds in the partial run, so it is risky for a strict 1-minute
  real-time budget.
- Before the sample-shape default gate, `window5` was poor for IMC WMRD. With
  the current IMC default gate it improves substantially, but `avg5` remains the
  best IMC WMRD choice among the three strategies.

### Current Status

No IMC optimization or training process was left running after this section.
The latest artifacts are saved under the corrected IMC run root above.

## 2026-06-30: Performance Evaluation hyperparameter/ablation setup

User requested Section 5 Performance Evaluation experiments before writing text:

1. verify baseline comparison code and smoke-test it;
2. run first-50-window sensitivity for Hot Filter eviction threshold `lambda`;
3. run first-50-window sensitivity for hot-flow splice threshold `phi`;
4. run decoder/component ablation on four datasets:
   `original`, `no_hot`, `origin_vit`, `origin_mlp`, `origin_cnn`;
5. save boxplot-style PDFs and summary tables for approval before modifying the paper.

Baseline compare code:

```text
zipf_fsd_release/compare/run_compare.sh
zipf_fsd_release/compare/run_all_compare.sh
zipf_fsd_release/compare/<trace>/src/main.cpp
zipf_fsd_release/compare/<trace>/traditional_sample.cpp
```

Supported compare traces are only:

```text
caida_2016, caida_2018, caida_2018_new, caida_org
```

Current main disk has split raw data for `caida_2016`, `caida_2018`, `imc`,
and `mawi`. It does not have runnable `compare/imc` or `compare/mawi`
baseline configs. Existing compare CSV/PDF results remain under `compare/*`.

Smoke test completed:

```text
compare/caida_2016 make: OK
traditional_sample array smoke on dataset_0010: OK
Output: /tmp/mrac_array_smoke_20260630.csv
WMRD=0.407491, MRD=1.981365, insert=98 ms
```

New/modified experiment support:

```text
zipf_fsd_release/src/mrac_data.py
  - added COUNTER_FEATURE_MODE
  - default "three" preserves old 3-channel [sorted, origin, reverse-sorted]
  - "origin" returns 1-channel origin-only counters for ablation

zipf_fsd_release/scripts/perf_eval_first50_runner.py
  - runs one trace/variant over first 50 online windows, default minute 5..54
  - uses avg5/K=5/E=5/samples-per-head=2000 setup
  - saves per-minute pred_1/pred_2 under runs/<trace>_<variant>/preds/
  - writes window_metrics.csv and summary.csv

zipf_fsd_release/scripts/perf_eval_sweeps_and_plots.py
  - builds lambda-specific temporary heavy_processor binaries
  - recomputes first-50 heavy CSVs for lambda sweep
  - computes phi/lambda sweeps from cached original predictions
  - derives no_hot from original predictions
  - writes boxplot PDFs and summary_all.csv
```

Validation completed:

```text
py_compile: OK with PYTHONPYCACHEPREFIX under run root
mrac_data default shape: (400, 3, 64, 64)
mrac_data origin shape:  (400, 1, 64, 64)
GPU smoke: origin_mlp, caida_2016, minute 5, E=1, OK
```

Important interpretation notes:

- `lambda` here is the Hot Filter / Elastic eviction threshold from `el.h`
  (`#define lambda 8`), not the residual gate parameter.
- `phi` is the split between neural cold-flow decoding and hot-flow direct
  decoding.
- Existing online result CSVs did not save raw `pred_1/pred_2`, so first-50
  predictions must be regenerated for sweeps.
- The current implementation uses the measured counter store plus a separate
  heavy CSV for final splicing; the lambda sweep recomputes the heavy CSVs
  while reusing the same neural predictions.

Planned run root:

```text
zipf_fsd_release/mainonly_runs_20260623/perf_eval_20260630/
```

### Completed results for this Performance Evaluation batch

Run root:

```text
zipf_fsd_release/mainonly_runs_20260623/perf_eval_20260630/
```

Artifacts:

```text
runs/*/window_metrics.csv                  # 16 training/inference runs
runs/*/preds/minute_*.npz                  # pred_1/pred_2 caches
sweeps/phi_detail.csv                      # 4 traces x 5 phi x 50 windows = 1000 rows
sweeps/lambda_detail.csv                   # 4 traces x 5 lambda x 50 windows = 1000 rows
ablations/decoder_ablation_detail.csv      # 4 traces x 5 variants x 50 windows = 1000 rows
summary_all.csv                            # compact means/p50/p95
plots/*.pdf                                # 16 PDFs
lambda_heavy/*                             # temporary lambda-specific heavy CSVs
```

No `perf_eval_first50_runner.py`, `perf_eval_sweeps_and_plots.py`, or
`heavy_processor` process was left running.

Important final setting:

```text
phi sensitivity was swept over {50,100,200,500,1000}.
The final lambda and decoder ablation tables/plots use default_phi=100,
because phi=100 is clearly the best or near-best stable choice on these traces.
```

Phi sweep mean WMRD/MRD:

```text
CAIDA2016: phi 50  WMRD=0.0439 MRD=0.2281; phi 100 WMRD=0.0447 MRD=0.2322; phi 1000 WMRD=0.0496 MRD=0.4441
CAIDA2018: phi 50  WMRD=0.0580 MRD=0.2932; phi 100 WMRD=0.0585 MRD=0.2973; phi 1000 WMRD=0.0614 MRD=0.4428
IMC:       phi 100 WMRD=0.2735 MRD=0.1400 is best; phi 50 is bad WMRD=0.4289
MAWI:      phi 100 WMRD=0.0678 MRD=0.0643 is best; phi 50 has MRD=0.1536
```

Lambda sweep at `phi=100`:

```text
lambda has small impact across 2..32.
lambda=2 is best WMRD for all traces in this first-50 sweep:
CAIDA2016 WMRD=0.0443 MRD=0.2146
CAIDA2018 WMRD=0.0584 MRD=0.2950
IMC       WMRD=0.2755 MRD=0.1623
MAWI      WMRD=0.0687 MRD=0.2041

Existing default lambda=8 is close in WMRD but slightly worse in MRD:
CAIDA2016 WMRD=0.0447 MRD=0.2322
CAIDA2018 WMRD=0.0585 MRD=0.2973
IMC       WMRD=0.2756 MRD=0.1630
MAWI      WMRD=0.0687 MRD=0.2149
```

Decoder/component ablation at `phi=100`:

```text
Mean WMRD:
              original  no_hot  origin_vit  origin_mlp  origin_cnn
CAIDA2016       0.0447  0.0505      0.0432      0.5041      0.1362
CAIDA2018       0.0585  0.0621      0.0574      0.5139      0.1487
IMC             0.2735  0.3065      0.2739      1.9519      0.2850
MAWI            0.0678  0.0710      0.0685      0.3819      0.1219

Mean MRD:
              original  no_hot  origin_vit  origin_mlp  origin_cnn
CAIDA2016       0.2322  0.5239      0.2322      0.4501      0.2664
CAIDA2018       0.2973  0.5217      0.2973      0.5275      0.3363
IMC             0.1400  0.5991      0.1394      0.5304      0.1429
MAWI            0.0643  0.5832      0.0643      0.3036      0.0794
```

Interpretation for later paper writing:

- Hot Filter/heavy splice is important, especially for MRD. Removing it
  (`no_hot`) increases MRD by roughly 2x to 9x depending on trace.
- One-layer MLP is not viable under the same online SFT budget.
- CNN is faster and better than MLP, but worse than ViT in WMRD and usually MRD.
- Origin-only ViT is comparable to the original 3-channel
  sorted/origin/reverse-sorted input in this first-50 sweep. The strongest
  supported claim is that ViT-style neural decoding and the Hot Filter are
  important; the extra sorted channels are not the dominant accuracy source in
  this specific ablation.

Baseline compare caveat:

- `compare/run_compare.sh` is runnable for CAIDA2016/CAIDA2018 on current disk.
- IMC/MAWI do not currently have traditional baseline compare configs.

### 2026-06-30 revision after user feedback

User asked to revise the Performance Evaluation figures/tables:

- Rename `original` to the English final-version label.
- Add the best residual optimization only to the final version so it beats
  `origin_vit`.
- Rename inference time to `Decoding Time`.
- Use forward-only decoding time, not metric/splice post-processing time.
- Split every paired plot into single-metric PDFs.
- Remove panel titles such as `CAIDA2016 WMRD`.
- Use `$\lambda$` and `$\phi$` symbols on axes.
- Swap MLP/CNN order in ablation plots.

Implemented in:

```text
scripts/perf_eval_sweeps_and_plots.py
```

New plot state:

```text
mainonly_runs_20260623/perf_eval_20260630/plots/
32 PDFs total:
  4 traces x 2 metrics x 2 params(lambda/phi) = 16 sensitivity PDFs
  4 traces x 2 error metrics = 8 decoder ablation error PDFs
  4 traces x 2 time metrics = 8 decoder ablation time PDFs
```

The old combined PDFs in `plots/` are removed when the plotter runs.

Final-version ablation label in CSV is now:

```text
variant=final
```

`final` means:

```text
3-channel ViT + Hot Filter/heavy splice + per-dataset residual optimization
```

Other ablation variants remain no-gate:

```text
no_hot, origin_vit, origin_cnn, origin_mlp
```

Per-dataset final residual optimization:

```text
CAIDA2016: selective residual gate, enable only when cumulative heavy median >= 0.50 or raw_scale_mean >= 1.10
CAIDA2018: up-only residual gate, threshold=1.00, cap=1.20
IMC:       two-way residual gate, threshold=1.02, cap=1.20, down=0.98, floor=0.70
MAWI:      two-way residual gate, threshold=1.00, cap=1.20, down=0.95, floor=0.70
```

Updated first-50 ablation means:

```text
Mean WMRD:
              final   no_hot  origin_vit  origin_cnn  origin_mlp
CAIDA2016    0.0431  0.0505      0.0432      0.1362      0.5041
CAIDA2018    0.0414  0.0621      0.0574      0.1487      0.5139
IMC          0.2276  0.3065      0.2739      0.2850      1.9519
MAWI         0.0469  0.0710      0.0685      0.1219      0.3819

Mean MRD:
              final   no_hot  origin_vit  origin_cnn  origin_mlp
CAIDA2016    0.2322  0.5239      0.2322      0.2664      0.4501
CAIDA2018    0.2972  0.5217      0.2973      0.3363      0.5275
IMC          0.1288  0.5991      0.1394      0.1429      0.5304
MAWI         0.0637  0.5832      0.0643      0.0794      0.3036
```

Forward-only decoding time is now:

```text
decoding_time_ms = infer_sec * 1000 / seed_count
```

It is about `0.22-0.27 ms` per two-head neural forward on one sketch input.

Training-time explanation:

```text
All ablation runs use the same epochs=5 and the same train samples:
  1800 train + 200 holdout per head after 10% holdout.

Final/original is slower because it uses 3-channel ViT input. Origin+ViT uses
1-channel input. MLP/CNN are smaller models, so per-epoch train time is lower.
The 10_1e4 head is consistently slower than 1_10 because its output dimension
is 1080 instead of 10.
```
## 2026-06-30 DaVinci EM parity update

User requested that DaVinci's counter-iteration method match MRAC/Elastic.

Implemented:

- `zipf_fsd_release/compare/caida_org/src/Sketchs/DaVinci/DaVinci.h`
  now uses the same `EMFSD` class used by MRAC/Elastic for Tower-counter FSD
  estimation, instead of DaVinci's custom `EMFSD1`.
- DaVinci Tower EM epochs are now `TOWER_EM_ITER=10`, matching the MRAC
  runner's 10-epoch setting.
- Recompiled `zipf_fsd_release/compare/caida_org/bin/davinci_runner`.
- Deleted only stale DaVinci result JSONs under:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/tasks/*/*_davinci_*/result.json
```

- Reran `scripts/run_comprehensive_compare.py` with `--sweep-windows 10
  --time-windows 100 --workers 32`. It regenerated summary CSVs and plots.

Current comprehensive comparison output root:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630
```

Updated plot files:

```text
plots/memory_sweep_decode_time.pdf
plots/memory_sweep_insert_speed.pdf
plots/memory_sweep_mrd.pdf
plots/memory_sweep_wmrd.pdf
plots/timeseries_{caida2016,caida2018,imc,mawi}_{mrd,wmrd}.pdf
```

Important interpretation:

- The previous DaVinci speed was not caused by empty counters. Its Tower
  counters are often nearly full/nonzero.
- Even with the same `EMFSD` class, DaVinci remains millisecond-level because
  Tower counters are capped at 15, so the EM counter-value support is small.
- Under the same `EMFSD` parity change, DaVinci's 16KB error worsened
  substantially because saturated Tower counters are treated like exact
  counters by `EMFSD` and Fermat decoding remains incomplete.

Updated 16KB time-series DaVinci means:

```text
CAIDA2016: WMRD=1.926378, MRD=1.643407, decode=1.949 ms
CAIDA2018: WMRD=1.937942, MRD=1.676920, decode=1.979 ms
IMC:       WMRD=0.479019, MRD=1.359940, decode=2.335 ms
MAWI:      WMRD=1.988044, MRD=1.635209, decode=1.738 ms
```

Sampling baseline state remains:

- Array/Hash Sample are fixed 1% flow-level samplers.
- Sample decode-time curves are intentionally omitted from
  `memory_sweep_decode_time.pdf`; in the paper we should say they are hash
  tables and only need one table traversal/materialization, not iterative EM
  decoding.

## 2026-06-30 IMC current-window oracle and 10% sample-error check

User asked why IMC remains high and whether current-window train+test should
approach the 10% sample-restored FSD error. Important state:

- A runner was added:

```text
zipf_fsd_release/scripts/run_imc_current_oracle.py
```

- It supports current-window oracle SFT: sample current window, build
  sample-restored FSD labels, train on that current-window distribution, then
  test the same current window.
- The non-final `e10_s2000_full` run was stopped after the user clarified the
  request. Do not treat it as a complete final experiment.
- Current usable results:

```text
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/sample_p10_error_rawtruth.csv
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/sweep_s2000_5_14/summary_sweep.csv
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/e20/summary.csv
```

Correct 10% sample-error result uses raw IMC 13B packet-key windows as ground
truth, not truncated `tr_ts` labels. Summary over IMC minute 5-97:

```text
10% flow-level sample restored FSD vs raw full FSD:
  full FSD:       WMRD mean=0.242906, MRD mean=1.722075
  freq <= 100:   WMRD mean=0.171989, MRD mean=1.077367
  freq <= 1000:  WMRD mean=0.225089, MRD mean=1.653201
  packet-mass relative error mean=0.681725
```

Interpretation:

- IMC has high variance under 10% flow-level sampling because a sampled hot
  flow is scaled by 10x and an unsampled hot flow disappears. This makes the
  packet-mass estimate noisy even though the estimator is unbiased.
- MRD is very high for pure sampling because it averages over many sparse FSD
  frequency buckets; missing or hallucinating tail buckets causes near-maximum
  relative errors.
- With more current-window training samples, the model moves toward the sample
  floor. On minutes 5-14, current-window oracle with 2000 training counters:

```text
epochs=5:  raw WMRD=0.217298, raw MRD=0.126853, sample-shape WMRD=0.182934
epochs=10: raw WMRD=0.215993, raw MRD=0.130247, sample-shape WMRD=0.175653
epochs=20: raw WMRD=0.192584, raw MRD=0.132862, sample-shape WMRD=0.182736
```

For those same minutes, 10% pure sample full-FSD WMRD mean is about 0.251695
and freq<=100 WMRD mean is about 0.170852, so the model+sample-shape output is
near the low-frequency sample-error floor.

Generated one IMC single-window visual requested by user:

```text
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/plots/imc_minute0005_raw_vs_sample_p10_fsd.pdf
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/plots/imc_minute0005_raw_vs_sample_p10_fsd.csv
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/plots/imc_minute0005_raw_vs_sample_p10_summary.csv
```

It plots raw IMC minute 5 FSD against 10% flow-sample restored FSD on the same
log-log axes. For this window, the restored sample packet mass is only 254,510
vs raw 1,000,000, so the visual shows a large under-sampling event caused by
missed high-packet flows.

Follow-up IMC 50% sample experiment:

- Built 50% flow-level sample cache:

```text
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/sample_cache_imc_p50
```

- Pure sample-restored FSD vs raw full IMC FSD over minute 5-97:

```text
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/sample_p50_error_rawtruth.csv

full FSD:       WMRD mean=0.093676, MRD mean=1.000930
freq <= 100:   WMRD mean=0.057646, MRD mean=0.366451
freq <= 1000:  WMRD mean=0.083435, MRD mean=0.911312
packet-mass relative error mean=0.217721
```

- Current-window train+test on p50 sample, `current_replicas=1`,
  `seed_count=2000`, `epochs=20`, evaluated with `phi=100` because
  `simulate_realtime_online.final_metrics` has `SPLICE_POINT=100`:

```text
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/p50_s2000_e20_full/window_metrics.csv
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/p50_s2000_e20_full/summary.csv

raw model:          WMRD mean=0.072995, MRD mean=0.078100
sample-shape final: WMRD mean=0.064301, MRD mean=0.071166
SFT time:           mean=29.30s, p95=32.11s
counter build:      mean=3.79s
decode:             mean=0.248s
```

The result confirms the user's intuition: with a higher sampling rate, the
current-window oracle approaches the low-frequency sample floor, and the hot
filter keeps large-flow MRD low despite pure-sample MRD being high.

## 2026-06-30 single-panel comprehensive plots with latest IMC NeuFSD

User asked to update the DaVinci decode plot, replace IMC NeuFSD with the
latest p50 current-window result, and avoid 4-panel combined figures. Added:

```text
zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py
```

Generated all plots here:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots_single_latest_imc/
```

Important files:

```text
legend_algorithms.pdf
legend_decode.pdf
memory_sweep_decode_ms_{caida2016,caida2018,imc,mawi}.pdf
memory_sweep_wmrd_{caida2016,caida2018,imc,mawi}.pdf
memory_sweep_mrd_{caida2016,caida2018,imc,mawi}.pdf
memory_sweep_insert_speed_{caida2016,caida2018,imc,mawi}.pdf
timeseries_wmrd_{caida2016,caida2018,imc,mawi}.pdf
timeseries_mrd_{caida2016,caida2018,imc,mawi}.pdf
summary_compare_latest_imc.csv
metadata.json
```

The latest IMC NeuFSD source used in these plots is:

```text
zipf_fsd_release/mainonly_runs_20260623/imc_current_oracle_20260630/p50_s2000_e20_full/window_metrics.csv
```

Updated IMC NeuFSD values in `summary_compare_latest_imc.csv`:

```text
memory10 (minute 5-14): WMRD=0.076503, MRD=0.061996
timeseries (minute 5-97): WMRD=0.064301, MRD=0.071166
```

DaVinci after the EM-parity change is still millisecond-level, not materially
slower in the fair decode path. Current memory-sweep decode means:

```text
16KB: CAIDA2016=1.94ms, CAIDA2018=2.03ms, IMC=2.40ms, MAWI=1.69ms
256KB: CAIDA2016=8.89ms, CAIDA2018=6.32ms, IMC=2.81ms, MAWI=3.39ms
```

Reason: DaVinci's Tower counters are capped at 15, and even with the same
`EMFSD` class as MRAC/Elastic, the EM operates on a very small counter-value
support. The parity change mostly hurt DaVinci accuracy, not decode time.

## 2026-07-01 DaVinci 2/4/8-bit Tower rerun

User asked whether many Tower counters were capped at 15, then requested a new
DaVinci variant with three Tower layers: 2-bit, 4-bit, and 8-bit counters, three
hashes, and EM decoding on the 8-bit layer. Implemented and reran all DaVinci
comparison tasks.

Code changes:

```text
zipf_fsd_release/compare/caida_org/src/Sketchs/DaVinci/tower.h
zipf_fsd_release/compare/caida_org/src/Sketchs/DaVinci/DaVinci.h
zipf_fsd_release/compare/caida_org/src/Sketchs/DaVinci/fermat.h
zipf_fsd_release/compare/caida_org/davinci_runner.cpp
```

Important implementation details:

- `TowerSketch(w_d)` now allocates `4*w_d` 2-bit counters, `2*w_d` 4-bit
  counters, and `w_d` 8-bit counters. Actual Tower memory is therefore
  `3*w_d` bytes.
- `davinci_runner.cpp` now budgets Tower memory as `tower_budget/3` and reports
  the actual total memory with `3*tower_mem`.
- `DaVinci::get_distribution()` copies the 8-bit layer into `EMFSD`, so the
  EM support cap is 255 instead of 15.
- The runner records both 8-bit capped counters (`value==255`) and the 4-bit
  middle-layer capped counters (`value==15`), so the old cap problem is visible.
- Fermat's very verbose per-bucket debug prints are gated by `DEBUG_F`; without
  this, one smoke-test window produced about 800k stdout lines.

Smoke test:

```text
IMC minute 10, 16KB:
MRD=1.60684, WMRD=0.542493
decode=21.13s
8-bit cap: 64/3182 = 2.01%
4-bit cap: 1637/6364 = 25.72%
```

All DaVinci tasks were rerun by deleting only DaVinci `result.json` files and
running:

```text
RUN_ROOT=/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630
python zipf_fsd_release/scripts/run_comprehensive_compare.py --run-root "$RUN_ROOT" --sweep-windows 10 --time-windows 100 --workers 32
```

Result status:

```text
DaVinci result.json count: 553 ok, 0 failed/timeout
```

New DaVinci aggregate over rerun result set:

```text
16KB  n=393 decode_mean=22.004s p95=26.564s WMRD=1.595  MRD=3.879e+08  cap8=0.1752 cap4=0.8061
32KB  n=40  decode_mean=21.436s p95=28.986s WMRD=1.413  MRD=1.263e+06  cap8=0.0255 cap4=0.6555
64KB  n=40  decode_mean=14.028s p95=24.708s WMRD=1.130  MRD=0.9756     cap8=0.0014 cap4=0.3314
128KB n=40  decode_mean=3.744s  p95=7.445s  WMRD=0.6871 MRD=0.6532     cap8=0.0000 cap4=0.1172
256KB n=40  decode_mean=0.936s  p95=1.880s  WMRD=0.3649 MRD=0.4206     cap8=0.0000 cap4=0.0330
```

16KB time-series by trace:

```text
CAIDA2016: decode_mean=26.188s WMRD=1.921 MRD=42.87    cap8=0.2966 cap4=0.9904
CAIDA2018: decode_mean=26.379s WMRD=1.930 MRD=68.92    cap8=0.2667 cap4=0.9885
IMC:       decode_mean=10.683s WMRD=0.459 MRD=1.452    cap8=0.0104 cap4=0.2032
MAWI:      decode_mean=23.973s WMRD=1.990 MRD=1.525e9 cap8=0.1154 cap4=0.9999
```

Conclusion: yes, `value==15` counters are very common in the old 4-bit layer,
especially at 16KB. Moving EM to the 8-bit layer greatly reduces hard capping
but makes DaVinci decode seconds-level to tens-of-seconds-level and does not
rescue accuracy at 16KB on CAIDA/MAWI.

Regenerated latest single-panel PDFs here:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots_single_latest_imc/
summary_compare_latest_imc.csv
```

## 2026-07-01 comprehensive-comparison plot style refresh

User requested the comprehensive-comparison plots to match the paper style used
by the "Effect of residual-mass calibration" figure.

Updated:

```text
zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py
```

Regenerated:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots_single_latest_imc/
```

Plot changes:

- Memory-sweep figures now use the residual-calibration style: `figsize=(8,4)`,
  tick font size 24, label font size 31, bold tick labels, dashed grids, and
  thicker lines.
- Memory x-axis now has 5% padding in log2 space, so 16KB and 256KB no longer
  sit on the borders.
- All memory-sweep lines use visible markers; NeuFSD horizontal references are
  now plotted as lines across the memory ticks instead of bare `hlines`.
- NeuFSD lines, including `NeuFSD-GPU` and `NeuFSD-CPU`, intentionally have no
  markers; other algorithms keep visible hollow markers.
- NeuFSD lines use a higher Matplotlib z-order than all baseline algorithms, so
  when curves overlap, NeuFSD is always drawn on top. NeuFSD uncertainty bands
  use a low z-order and remain behind the lines.
- Decode y-label is now exactly `Time (s)`.
- Insert-speed y-label is now exactly `Speed (Mps)`.
- Decode plots keep all decode-comparison curves in view:
  `NeuFSD-GPU`, `NeuFSD-CPU`, `Elastic`, `MRAC`, and `DaVinci`. Array/hash
  sample remain omitted from decode plots per the earlier paper decision that
  they do not perform an EM/NN decode step.
- Error memory-sweep plots set the log-y upper bound from non-DaVinci curves
  plus NeuFSD, so DaVinci's extreme MRD outliers may clip instead of compressing
  the useful range.
- Error-vs-time PDFs were also refreshed with the same font sizes, line widths,
  5% x-axis padding, x-label `Time (minute)`, and y-axis limits that ignore
  DaVinci's extreme outliers.
- Error-vs-time PDFs use a common global x-axis range across datasets. IMC has
  fewer than 100 measurable windows, but its WMRD/MRD time plots still use the
  same right boundary as CAIDA2016/CAIDA2018/MAWI and leave the missing tail
  blank.

Verification:

```text
PYTHONPYCACHEPREFIX=/tmp/mrac_pycache_check python -m py_compile zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py
python zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py --run-root /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630
```

The plot directory still contains 26 PDF files plus CSV/metadata. No PNGs were
generated into the experiment directory.

## 2026-07-01 Overleaf performance-evaluation rewrite

User asked to continue writing the paper in `overleaf/NeuFSD-sigmetrics.tex`,
delete the old `\subsection{Experimental Results}` and old figures, update
`\subsection{Experiment Setup}`, and add the new comprehensive comparison after
`\subsection{Decoder Architecture Ablation}`.

Updated files:

```text
overleaf/NeuFSD-sigmetrics.tex
overleaf/Figure-FSD/perf-eval/comprehensive/
```

The comprehensive PDFs copied into Overleaf are from:

```text
zipf_fsd_release/mainonly_runs_20260623/comprehensive_compare_20260630/plots_single_latest_imc/
```

New/updated paper content:

- `Experiment Setup` now uses the current four datasets:
  CAIDA2016, CAIDA2018, IMC, and MAWI.
- Comparison algorithms now include Elastic Sketch, MRAC, DaVinci Sketch,
  Array Sample, and Hash Sample.
- Sampling is described as fixed 1% flow-level sampling with finite table
  capacity; sampled flows are kept entirely, unsampled flows are dropped, and
  the sampled FSD is restored by dividing by the sampling rate.
- NeuFSD's final configuration is described as `64x64` counter array (16KB),
  `lambda=8`, `phi=100`, Avg-5 continuous SFT, 2,000 online training examples
  per update, and residual-mass calibration.
- Added `\subsection{End-to-End Comparison}` with six new figure groups:
  insertion speed, decoding time, WMRD memory sweep, MRD memory sweep, WMRD
  over time, and MRD over time.
- Old `\subsection{Experimental Results}` and old CAIDA-only/sample comparison
  figure references were deleted.
- Text analysis emphasizes:
  NeuFSD's sketch-like insertion path, millisecond neural decoding, EM
  latency of MRAC/Elastic/DaVinci, DaVinci instability at small memory,
  sample WMRD/MRD asymmetry, Elastic's memory-dependent insertion speed, and
  NeuFSD's stability on IMC under window-to-window FSD shifts.
- Terminology was cleaned up to use `hot flow` and `cold flow` consistently in
  prose. Remaining `heavy` strings are only citation keys or paper names such
  as `ben2016heavy` and `shi2025heavylocker`.

Static checks performed:

```text
rg old Experimental Results / old CAIDA figure names / old sample labels: no matches
all includegraphics paths in NeuFSD-sigmetrics.tex exist
all \ref{...} targets have a corresponding \label{...}
figure/table/itemize/algorithm begin/end counts match
duplicate labels: 0
```

Local LaTeX compile was not possible in this environment because none of
`latexmk`, `pdflatex`, `xelatex`, or `tectonic` is installed. The source is
ready for Overleaf-side compilation.

## 2026-07-01 paper polish after comprehensive section

User requested five follow-ups:

1. enlarge markers in the line plots;
2. shorten new figure captions so they fit better in one-column display;
3. add DaVinci Sketch to Table 1;
4. split `End-to-End Comparison` into `subsubsection`s;
5. review `review.md` and identify unresolved reviewer concerns that still
   require new experiments or analysis.

Implemented:

```text
zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py
overleaf/Figure-FSD/perf-eval/comprehensive/*.pdf
overleaf/NeuFSD-sigmetrics.tex
```

Plot updates:

- Increased main line-plot marker size from 12 to 15 and marker edge width
  from 2.4 to 2.8.
- Increased legend marker size from 11 to 14.
- Regenerated the comprehensive comparison PDFs and copied the 26 PDFs into
  `overleaf/Figure-FSD/perf-eval/comprehensive/`.

Paper updates:

- Added `DaVinci Sketch` to Table 1
  (`Qualitative Comparison of FSD Estimation Algorithms`).
- Split `End-to-End Comparison` into:
  `Evaluation Protocol`, `Insertion Speed`, `Decoding Latency`,
  `Accuracy Under Memory Scaling`, and `Temporal Stability`.
- Shortened captions:
  `Insertion speed vs. memory.`, `Decoding time vs. memory.`,
  `WMRD vs. memory.`, `MRD vs. memory.`, `WMRD over time.`, `MRD over time.`
- Removed stale Overleaf TODO comments below Table 1.
- Renamed placeholder figure references to formal names:
  `online_measurement_workflow.jpg` and `sft_window_strategies.jpg`.
- Unified sparse-output description with final `phi=100` setting:
  the final output head is described as 19 neurons with keypoint interval 10.
- Replaced ViT patch-count symbol `N` with `N_p` to avoid conflict with
  packet count `N`.
- Reduced over-strong wording around theoretical claims and speedups:
  changed the contribution to `Design Analysis`, removed `shatters`,
  and described CPU/GPU decoding separately instead of only claiming
  `>10,000x`.
- Changed Hot Filter analysis wording from an exact necessary condition to a
  simplified competition-model bound. This does not fully solve the rigorous
  proof issue but avoids directly making the flawed claim highlighted by the
  reviewer.

Static checks:

```text
begin/end counts OK for figure, figure*, table, table*, itemize, enumerate, algorithm
duplicate labels: none
missing refs: none
missing includegraphics: none
rg placeholder/phi=1000/109/j from 1 to 100/over 10,000/shatters: no matches
```

Reviewer gaps still needing new experiments or deeper rewrites:

- Mathematical rigor: Hot Filter miss proof still needs a true arrival-order
  aware proof or an adversarial arrival-order experiment. Current text is only
  softened.
- Decoder/generalization analysis: Section 4 says design analysis but still
  lacks a formal neural generalization/error decomposition. Add either a
  decomposition or remove further theoretical claims if the paper is tight.
- Generalizability stress tests: add early-window train/later-window test with
  gaps such as 10/50/100/500 windows, plus cross-trace transfer and abrupt
  trace-shift stress tests.
- Training label cost/noise: sweep exact labels vs sampled labels vs
  MRAC/Elastic-derived labels, and sample rates such as 0.1%, 0.5%, 1%, 5%.
  Report label error, final NeuFSD error, CPU/GPU preparation time, sample
  table memory, and sample bandwidth.
- Retraining frequency: sweep SFT interval 1/2/5/10/20 windows and maybe a
  drift-triggered update policy; report accuracy vs training overhead.
- Packet count/window size `N`: sweep 10K/50K/100K/500K/1M packets per window
  and report WMRD/MRD, SFT time, and decoding time.
- `lambda`/`phi` sensitivity currently covers accuracy only. Add resource and
  overhead metrics: Hot Filter occupancy, eviction rate, insertion speed,
  exported hot entries, output dimension, SFT time, and decoding time.
- Decode fairness: current paper now includes NeuFSD-CPU, but a stronger
  response should split pure forward pass from full control-plane decode
  (snapshot transfer, folding, sorting/reshape, interpolation).

## 2026-07-01 time-series legend and P4/DaVinci feasibility note

User requested that over-time figure legends use pure lines without markers,
asked for reviewer-gap mapping to concrete reviewer questions, and asked how
to add DaVinci to the P4 hardware table without access to the switch.

Implemented:

```text
zipf_fsd_release/scripts/plot_comprehensive_single_latest_imc.py
overleaf/Figure-FSD/perf-eval/comprehensive/legend_algorithms_lines.pdf
overleaf/NeuFSD-sigmetrics.tex
```

Plot/tex changes:

- Added `legend_algorithms_lines.pdf`, a pure-line legend with no markers.
- Regenerated comprehensive PDFs and copied them to Overleaf.
- In `NeuFSD-sigmetrics.tex`, memory-sweep figures still use
  `legend_algorithms.pdf` with markers, while the WMRD/MRD over-time figures
  now use `legend_algorithms_lines.pdf`.
- Static check: all `includegraphics` paths exist.

P4 feasibility notes:

- Local P4 repo `NeuFSD-p4-main` includes `neufsd`, `mrac`, `sample`, and
  `elastic_sketch` P4 programs plus `_latency` variants, but no DaVinci P4.
- `NeuFSD-p4-main/script/collect_resource_usage.sh` copies resource logs only
  for `elastic_sketch`, `mrac`, `sample`, and `neufsd`.
- Without a Tofino switch, exact throughput/latency cannot be reproduced.
  However, if the Tofino SDE/Open P4 Studio toolchain is available, we can
  still compile a DaVinci P4 program against the Tofino model/compiler and get
  compiler resource reports (`mau.resources.log`) plus model-level functional
  simulation. BMv2/simple_switch can validate behavior but not real Tofino
  latency/resource timing.

## 2026-07-03 figure-name sync and math-rigor prompt

User requested three paper-maintenance tasks:

1. The framework overview figure now names the three counter-array views
   `Descending`, `Unsorted`, and `Ascending`; the paper text must match this
   order.
2. `fig:online_measurement_system` and `fig:sft_window_strategies` are now PDF
   assets instead of JPG.
3. A detailed prompt is needed for a mathematically strong LLM to repair the
   unresolved `Mathematical Analysis Rigor` issue in `review_action_items.md`,
   including a proof target for `Optimization: Residual-Mass Calibration`.

Implemented:

```text
overleaf/NeuFSD-sigmetrics.tex
math_rigor_prompt_for_llm.md
overleaf/Figure-FSD/online-measurement/online_measurement_workflow.pdf
overleaf/Figure-FSD/online-measurement/sft_window_strategies.pdf
```

Paper updates:

- Updated the input-preprocessing text to define the three views as
  descending, unsorted, and ascending, matching `fig:framework_overview`.
- Updated Algorithm `NeuFSD Offline Decoding` so the tensor stack order is
  `a_desc`, `a_unsort`, `a_asc`.
- Updated decoder-ablation prose: `Origin+ViT` now means using only the
  unsorted/original counter-array order, with descending and ascending views
  removed.
- Replaced the two online-measurement figure includes from `.jpg` to `.pdf`.
- The local tree did not contain the new PDF files yet, so same-name PDFs were
  generated from the existing JPG placeholders to keep LaTeX compilable. If the
  user has professional PDF versions, replace these two files in place.

Math-rigor handoff:

- New file `math_rigor_prompt_for_llm.md` is a self-contained prompt for a
  stronger mathematical model. It includes the NeuFSD insertion/query
  algorithm, current simplified Hot Filter proof, reviewer criticism, required
  arrival-order-aware proof/counterexample tasks, an end-to-end error
  decomposition request, and a residual-mass calibration proof request.
- The main unresolved proof issue remains open. The prompt explicitly asks the
  next model to avoid overclaiming: if a useful Hot Filter bound is impossible
  under adversarial arrival order, it should give a counterexample and provide
  a correct theorem under random-order or Poisson-arrival assumptions.

Static checks:

```text
rg old jpg references / reverse-sorted / old sorted variables: no matches
online_measurement_workflow.pdf exists
sft_window_strategies.pdf exists
```

## 2026-07-04 local TeX Live 2024 / pdfLaTeX setup

User requested a local LaTeX environment matching the Overleaf settings:
`pdfLaTeX` with TeX Live 2024.

Installed and verified:

```text
TeX Live root: /home/stallone1/texlive/2024
Installer cache: /home/stallone1/.cache/texlive2024-installer
pdflatex: /home/stallone1/.local/bin/pdflatex
latexmk: /home/stallone1/.local/bin/latexmk
pdfTeX version: 3.141592653-2.6-1.40.26 (TeX Live 2024)
latexmk version: 4.86a
```

Implementation notes:

- Used the official frozen TeX Live 2024 repository:
  `https://ftp.math.utah.edu/pub/tex/historic/systems/texlive/2024/tlnet-final`.
- Installed a basic TeX Live tree plus the packages needed by the current
  Overleaf paper, including `acmart`, `latexmk`, `newtx`, `libertine`,
  `inconsolata`, `algorithm2e`, `algorithmicx`, `siunitx`, `diagbox`,
  `makecell`, `subfigure`, `pbalance`, and their dependencies.
- Added TeX Live PATH initialization to `/home/stallone1/.bashrc` and
  `/home/stallone1/.profile`.
- Also created symlinks in `/home/stallone1/.local/bin` for `pdflatex`,
  `latexmk`, `bibtex`, `tlmgr`, `kpsewhich`, `latex`, `pdftex`, and
  `mktexlsr`, because `.bashrc` returns early for non-interactive shells.

Source compatibility fixes made for local pdfLaTeX:

```text
overleaf/NeuFSD-sigmetrics.tex
overleaf/Reference.bib
```

- In `NeuFSD-sigmetrics.tex`, added local command-conflict guards for
  `\Bbbk`, `\Letter`, and `\Cross`.
- In `NeuFSD-sigmetrics.tex`, provided missing math macros `\Prob`, `\E`,
  and `\I`.
- In `Reference.bib`, removed duplicate BibTeX keys that stopped BibTeX.
- In `Reference.bib`, added author/year metadata for URL-style entries so the
  ACM bibliography style does not emit invalid duplicate `[n.d.]` labels.

Compilation status:

```text
cd /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf
latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode -halt-on-error %O %S' NeuFSD-sigmetrics.tex
```

The command succeeds. The generated paper is:

```text
/home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf/NeuFSD-sigmetrics.pdf
```

## 2026-07-04 Overleaf refresh: re-applied local compile fixes

User uploaded a newer `overleaf/` directory and asked to re-apply any previous
local pdfLaTeX/BibTeX fixes that had been overwritten.

Files touched:

```text
overleaf/NeuFSD-sigmetrics.tex
overleaf/Reference.bib
```

Re-applied `NeuFSD-sigmetrics.tex` fixes:

- Added `\let\Bbbk\relax` before `\usepackage{amssymb}` to avoid the
  `newtxmath`/`amssymb` command conflict in local TeX Live 2024.
- Added `\let\Letter\relax` and `\let\Cross\relax` before
  `\usepackage[misc,geometry]{ifsym}` to avoid `marvosym`/`ifsym` conflicts.
- Added fallback definitions for `\Prob`, `\E`, and `\I` after loading
  `proba`, because the paper uses these macros and the local package set did
  not provide them in the expected form.

Re-applied `Reference.bib` fixes:

- Removed duplicate BibTeX keys restored by the upload:
  `zhangoctosketch`, `chen2021out`, `chen2021precise`, `wu2023unbiased`,
  `yang2019diamond`, `tang2020fast`, and `jia2021bidirectionally`.
- Added `author`/`year` metadata to URL-style dataset/software entries:
  `CAIDA`, `IMC`, `MAWI`, `github`, `redis`, `redisbloom`, and `bess`.

Verification:

```text
Reference.bib entries: 176
Reference.bib unique keys: 176
duplicate keys: none

cd /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf
latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode -halt-on-error %O %S' NeuFSD-sigmetrics.tex
```

The command succeeds under local TeX Live 2024 and writes:

```text
overleaf/NeuFSD-sigmetrics.pdf
```

Current output is 39 pages. Remaining messages are non-fatal LaTeX/BibTeX
warnings such as missing page metadata in some references, ACM image-description
warnings, and PDF inclusion version warnings.

## 2026-07-04 Overleaf latest upload verification

User uploaded a newer `overleaf/` directory and asked to re-check whether the
previous BibTeX and pdfLaTeX compatibility fixes still apply.

Files touched in this pass:

```text
overleaf/NeuFSD-sigmetrics.tex
HANDOFF.md
```

Status after verification:

- Local TeX environment is TeX Live 2024 at
  `/home/stallone1/texlive/2024`; `pdflatex` and `latexmk` are available through
  `/home/stallone1/.local/bin`.
- `wrapfig.sty` is installed and found by `kpsewhich`.
- The uploaded `NeuFSD-sigmetrics.tex` already retained the important macro
  guards: `\let\Bbbk\relax`, `\let\Letter\relax`, `\let\Cross\relax`, and
  fallback definitions for `\Prob`, `\E`, and `\I`.
- The online measurement figures now correctly reference PDF files and both use
  width `0.99\textwidth`:
  `Figure-FSD/online-measurement/online_measurement_workflow.pdf` and
  `Figure-FSD/online-measurement/sft_window_strategies.pdf`.
- Redis/RedisBloom/BESS citations are present in the text and the corresponding
  BibTeX entries exist in `Reference.bib`.
- `Reference.bib` duplicate-key check reports `duplicate keys: none`.

Small source cleanup made in `NeuFSD-sigmetrics.tex`:

- Changed the MRD/WMRD metric formulas from numbered `equation` environments
  with `\notag` to display math `\[...\]`, removing duplicate PDF anchor
  warnings for `equation.1`.
- Split the long Hot Filter colliding-mass sentence into a short display
  equation, removing the remaining overfull line warning.

Verification command:

```text
cd /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf
latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode -halt-on-error %O %S' NeuFSD-sigmetrics.tex
```

Result:

```text
Output written on NeuFSD-sigmetrics.pdf (35 pages, 2645166 bytes).
```

Historical non-fatal warnings from this intermediate compile (superseded by the
later "final proof/layout audit" below):

- `wrapfig` reported placement/collision warnings for the compact MAWI-only
  wrapfigures in the evaluation section. These were fixed later by adding an
  explicit optional line count to each wrapfigure.
- `acmart` warns that authors' addresses are mandatory. This is expected because
  `\authorsaddresses{}` is intentionally used to suppress the printed
  "Author's Contact Information" block for review formatting.
- `acmart` image-description warnings and PDF inclusion version warnings remain;
  they do not affect compilation.

## 2026-07-04 final proof/layout audit after latest upload

Files touched:

```text
overleaf/NeuFSD-sigmetrics.tex
overleaf/appendix-KDD.tex
HANDOFF.md
```

Math/proof cleanup:

- Changed the problem statement from a packet multiset to an ordered sequence
  `S=(p_1,...,p_N)`, while defining the FSD from the induced flow multiset. This
  matches the order-aware Hot Filter proof and directly addresses the reviewer
  concern about arrival order.
- Replaced the scalar/vector overload of `H` in the residual proof:
  `M_{\mathrm{hot}}` is now hot-spliced packet mass, and
  `n_B^{\mathrm{hot}}` is the hot-tail FSD vector.
- Clarified the end-to-end decomposition. The true residual proof now defines
  residual key masses `a_x`, the decoded-support residual FSD
  `q_{0,i}=|{x:a_x=i}|` for `1<=i<=phi`, and explicitly charges residual keys
  with mass `>phi` to splice error.
- Replaced the ambiguous `\mathcal C_R` in the appendix with a defined operator
  `\mathcal C_{\bar R}` and specified the `r^T q=0` skip case.
- Added `R>0` to the residual-mass calibration theorem assumptions and noted
  that the `R=0` case is degenerate for normalized shapes and handled by the
  implementation skip/clipping rule.
- Added `f_e>=2` to the hash-averaged Hot Filter corollary, matching the theorem
  it invokes.
- Added a sentence in the main Hot Filter analysis pointing readers to the
  appendix for the complementary "not sufficient" counterexample.
- Removed the second full "Expectation-Maximization (EM)" definition in the
  introduction; the paper now avoids the reviewer-noted repeated EM definition.

Layout/compile cleanup:

- Changed the four compact MAWI evaluation figures to
  `\begin{wrapfigure}[7]{r}{0.48\textwidth}`, which removes the previous
  `wrapfig` collision/forced-float warnings.
- Verified both online measurement figures still reference the PDF assets and
  use `width=0.99\textwidth`.
- Verified captions have no source lines over 150 characters.
- Verified `Reference.bib` has no duplicate keys.
- Verified review-spelling scans are clean for the explicit typo strings from
  `review.md` (`particluar`, `dstinguishable`, `defintions`, `notatin`, etc.)
  and for placeholder strings (`Section XX`, `Figure X`, `TODO`, `FIXME`).

Latest verification command:

```text
cd /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/overleaf
latexmk -pdf -pdflatex='pdflatex -interaction=nonstopmode -halt-on-error %O %S' NeuFSD-sigmetrics.tex
```

Latest result:

```text
Output written on NeuFSD-sigmetrics.pdf (35 pages, 2647056 bytes).
```

Main-body page boundary from `NeuFSD-sigmetrics.aux`:

```text
Section 6 Conclusion starts on page 21.
References start on page 22.
Appendix A (red major revisions) starts on page 23.
```

Remaining non-fatal warning:

- `acmart` still warns that authors' addresses are mandatory. This is expected:
  `\authorsaddresses{}` intentionally suppresses the printed "Author's Contact
  Information" block.
