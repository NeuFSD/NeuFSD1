# 路径映射（原文件不改写）

| 原路径前缀 | 包内路径前缀 | 说明 |
|---|---|---|
| /home/jovyan/zhaoguangxiang-data/shiqilong/MRAC/ | source/A/ | 实际可读 A |
| /zhaoguangxiang-data/shiqilong/MRAC/ | source/A/ | 仅挂载候选映射；给定短路径本机 ENOENT |
| /zhaoguangxiang-data-zzzc/shiqilong/MRAC/ | source/B/ | 实际可读 B |
| /home/jovyan/zhaoguangxiang-data-zzzc/shiqilong/MRAC/ | source/B/ | B 已核实 realpath 别名 |

日志摘录对应 records/A 或 records/B，扩展名 .tail300.txt。只对 manifest 中存在的文件有副本；大输入和权重不在包内。接收方可用自己的位置建立路径映射，但不能把新输入映射后自动认定为旧图原输入。不要直接执行归档中的旧启动/cleanup脚本。

相对路径如 configs/...、mainonly_runs_20260623/...：只有 launcher 的 cd/cwd 证据才可确定历史绝对路径。当前表中的 conditional_candidate_cwd_unrecorded 是基于目录布局的待确认候选，不是已确认cwd。index.json 的 data_file 则由 mrac_data.py 的 with_name 规则按该索引所在目录解析。外部引用只记录具体路径，不递归扩展父目录。ZIP 内不含符号链接。
